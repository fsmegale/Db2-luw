Readme

##########################################################################################
####################### WR Project - WORKLOAD REPOSITORY - DB2 ###########################
##########################################################################################
## The following 2 scripts keep a history from many catalog views such as:
/home/db2inst1/scripts/dbworkload/getdbworkload.sh
/home/db2inst1/scripts/dbworkload/getdbworkload_daily.sh
 - MON_GET_PKG_CACHE_STMT
 - MON_GET_CONTAINER
 - MON_GET_MEMORY_POOL
 - MON_GET_MEMORY_SET
 - TBSP_UTILIZATION
 - SYSCAT_WORKLOADS
 - WLM_GET_WORKLOAD_STATS
 - MON_TBSP_UTILIZATION
 - SYSIBMADM_PRIVILEGES
 - SYSCAT_ROLEAUTH
 - REG_VARIABLES
 - SYSCAT_TABAUTH
 - SYSCAT_DBAUTH
 - SYSCAT_TABLESPACES
 - SYSCAT_TABLES
 - SYSCAT_INDEXES
 - SYSCAT_COLUMNS
 - MON_GET_TABLESPACE
 - SYSCAT_DATAPARTITIONS
 - TABLESPACE_USAGE
 - SYSCAT_THRESHOLDS

# Script that collects data from connections "arriving" at the connection port on the 
# database servers. The goal is to retain this connection data for futher investigation 
# when dimensioning connections configured in DB2
/home/db2inst1/scripts/dbworkload/getsumaryhostconn.sh

# Script that get connection details but in database using SYSIBMADM.LONG_RUNNING_SQL, 
# MON_GET_UNIT_OF_WORK, MON_GET_CONNECTION, MON_GET_MEMORY_POOL, SYSPROC.MON_GET_TRANSACTION_LOG
/home/db2inst1/scripts/dbworkload/getdbconnections.sh

## This script help us a lot to identify the DMLs workload over the tables so we can better 
# adjusting the identity cache from tables that have columns with identity property.
Catalog views: MON_GET_TABLE, SYSCAT.DATAPARTITIONS, SYSIBM.SYSCOLUMNS, 
# SYSIBM.SYSDEPENDENCIES and SYSIBM.SYSSEQUENCES
/home/db2inst1/scripts/dbworkload/getdbtableaccess.sh

## This script get the table size using the SYSPROC.ADMIN_GET_TAB_INFO table function. 
/home/db2inst1/scripts/dbworkload/sh_GetTableSize_v1.sh

# All those scripts has the main purpose is to kepp a history from some catalog views so you can compare, check old datas and so on. 
##########################################################################################
##########################################################################################
##########################################################################################

##########################################################################################
##################################### Checkup DB2 ########################################
##########################################################################################
## This file has a set of queries to help you to check:
 - Currently connections
 - Connections with a open transaction
 - Top queries
 - Transaction log usage by connection ( handle )
 - Memory pool
 - Table stats out of date
 - Latches

db2.backup.sql
db2.CheckUpDB2.sql
db2.event.monitor.sql
db2.foreign.key.sql
db2.statistics.sql
db2.table.schema.size.sql
db2.tables.sql
db2.TBS_ALLOCATED.sql
db2.used.indexes.sql
db2.wlm.sql
db2.wr.sql