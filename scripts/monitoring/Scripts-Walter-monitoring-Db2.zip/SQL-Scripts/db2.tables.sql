 -- Consulta para recuperar dados das tabelas como tablespace bufferpool etc
SELECT 
       A.OWNER, A.TABSCHEMA,
        A.TABNAME,
        A.TYPE,
                CASE TYPE
                WHEN 'A' THEN 'ALIAS'
                WHEN 'G' THEN 'CREATED TEMPORARY TABLE'
                WHEN 'H' THEN 'HIERARCHY TABLE'
                WHEN 'L' THEN 'DETACHED TABLE'
                WHEN 'N' THEN 'NICKNAME'
                WHEN 'S' THEN 'MATERIALIZED QUERY TABLE'
                WHEN 'T' THEN 'TABLE'
                WHEN 'U' THEN 'TYPED TABLE'
                WHEN 'V' THEN 'VIEW'
                WHEN 'W' THEN 'TYPED VIEW'
         END TYPE,
        A.REFRESH, A.REFRESH_TIME,
        A.TABLEORG,
        A.APPEND_MODE,
        A.LOCKSIZE,
        A.CLUSTERED "MDC", 
        A.VOLATILE,
        A.TBSPACE, 
        A.INDEX_TBSPACE,
        A.LONG_TBSPACE, 
        C.BPNAME,        
        A.NPAGES, A.MPAGES, A.FPAGES, A.TABLEORG,
        B.PAGESIZE, B.EXTENTSIZE, TRIM(VARCHAR_FORMAT(A.CARD, '999,999,999,999')) AS CARD,
        A.CARD,
        A.COMPRESSION, A.ROWCOMPMODE, A.TEMPORALTYPE,
        A.DATACAPTURE,
        A.CREATE_TIME, A.STATS_TIME, A.INVALIDATE_TIME, A.ALTER_TIME, A.LASTUSED,
        A.AVGROWSIZE
FROM SYSCAT.TABLES A 
LEFT JOIN SYSCAT.TABLESPACES B 
        ON A.TBSPACEID = B.TBSPACEID
LEFT JOIN SYSCAT.BUFFERPOOLS C 
        ON B.BUFFERPOOLID = C.BUFFERPOOLID
WHERE 1=1
        AND A.TABSCHEMA NOT LIKE 'SYS%' AND A.TABSCHEMA NOT IN ('ASN','IBM_RTMON','REP','DB2EXT','DB2INST1')
        AND A.TYPE = 'T'
        --AND A.CLUSTERED IS NULL
        --AND A.COMPRESSION = 'N'
     WITH UR;

-- OBS: Database temporal tables must have the dependencies breaked with the main table
db2 "ALTER TABLE SCHEMA.TABLE_NAME DROP VERSIONING"
db2 "CALL SYSPROC.ADMIN_MOVE_TABLE('SCHEMA','TABLE_NAME','TBS_DT_WR_HISTORY','TBS_DT_WR_HISTORY','TBS_DT_WR_HISTORY','','','','','COPY_USE_LOAD','MOVE')"
db2 "ALTER TABLE SCHEMA.TABLE_NAME ADD VERSIONING USE HISTORY TABLE SCHEMA.TABLE_NAME"
;

-- Estimar area temporaria para criacao do indice
SELECT
        C.TABSCHEMA, C.TABNAME, 'ESTIMATE TEMPORARY SPACE REQUIRED FOR INDEX CREATION: IDX_OCORRENCIADIRECIONAMENTOATIVIDADE_16 - ',
        ( ( SUM ( C.LENGTH ) + 8 ) * 
        (SELECT T.CARD FROM SYSCAT.TABLES AS T WHERE T.TABSCHEMA = C.TABSCHEMA AND T.TABNAME = C.TABNAME) * 
        4 ) / 1024 / 1024 / 1024
        --C.TABNAME, C.TABSCHEMA, COLNAME, C.TYPENAME, C.LENGTH
FROM SYSCAT.COLUMNS AS C 
WHERE C.TABNAME = ''
AND C.COLNAME IN ('')
GROUP BY C.TABSCHEMA, C.TABNAME
WITH UR;



-- Identificar as tabelas com temporal table habilitado
SELECT 
'ALTER TABLE '||TRIM(TABSCHEMA)||'.'||SUBSTR(TABNAME,4)||'  DROP VERSIONING;'||CHR(13)||'ALTER TABLE '||TRIM(TABSCHEMA)||'.'||TABNAME||'  DROP RESTRICT ON DROP;',
TB.TABNAME, TB.TABSCHEMA, TS.TBSPACE, TS.NGNAME
  FROM SYSCAT.TABLES TB, SYSCAT.TABLESPACES TS 
 WHERE TYPE = 'T' 
   AND DROPRULE = 'R' 
   AND TB.TBSPACEID = TS.TBSPACEID 
 ORDER BY TS.NGNAME, TS.TBSPACE, TB.TABSCHEMA, TB.TABNAME;

-- Storage - Table Performance
WITH unicode_fix
    (
        x
    ) AS
    (SELECT NULL
        FROM sysibm.sysdummy1
    )
    ,
    by_member AS
    ( SELECT t.member,
            t.tabschema AS tabschema,
            t.tabname   AS tabname,
            t.tab_type,
            MIN(s.tbsp_name)                                                       AS tbsp_name,
            SUM(t.table_scans)                                                     AS table_scans,
            SUM(t.rows_read)                                                         AS rows_read,
            SUM(t.rows_inserted)                                                   AS rows_inserted,
            SUM(t.rows_updated)                                                     AS rows_updated,
            SUM(t.rows_deleted)                                                     AS rows_deleted,
            SUM(t.object_data_l_reads) + SUM(t.object_xda_l_reads) + SUM(t.object_col_l_reads) AS
            logical_reads,
            SUM(t.object_data_p_reads) + SUM(t.object_xda_p_reads) + SUM(t.object_col_p_reads) AS
            physical_reads,
            SUM(t.object_data_lbp_pages_found) + SUM(t.object_xda_lbp_pages_found) + SUM
            (t.object_col_lbp_pages_found) AS lbp_pages_found,
            SUM(t.data_object_l_pages)     AS data_object_l_pages,
            SUM(t.index_object_l_pages)    AS index_object_l_pages,
            SUM(t.xda_object_l_pages)      AS xda_object_l_pages,
            SUM(t.lob_object_l_pages)      AS lob_object_l_pages,
            SUM(t.long_object_l_pages)     AS long_object_l_pages,
            SUM(p.page_reclaims_x)         AS page_reclaims_x,
            SUM(p.page_reclaims_s)         AS page_reclaims_s
        FROM TABLE(mon_get_table(NULL, NULL, -2)) t
        LEFT OUTER JOIN TABLE(mon_get_tablespace(NULL, -2)) s
        ON  t.tbsp_id = s.tbsp_id
            AND t.member = s.member
        LEFT OUTER JOIN TABLE(mon_get_page_access_info(NULL, NULL, -2)) p
        ON  t.tabschema = p.tabschema
            AND t.tabname = p.tabname
            AND t.member = p.member
        WHERE 1 = 1
          --AND T.TABSCHEMA = 'CLI'
       --   AND T.TABNAME = 'TGFONTERENDA'
        GROUP BY t.member,
            t.tabschema,
            t.tabname,
            t.tab_type
    )
SELECT tabschema,
    tabname,
    tab_type,
    MIN(tbsp_name)       AS tbsp_name,
    SUM(table_scans)     AS table_scans,
    SUM(rows_read)       AS rows_read,
    SUM(rows_inserted)   AS rows_inserted,
    SUM(rows_updated)    AS rows_updated,
    SUM(rows_deleted)    AS rows_deleted,
    SUM(logical_reads)   AS logical_reads,
    SUM(physical_reads)  AS physical_reads,
    SUM(lbp_pages_found) AS lbp_pages_found,
    CASE
        WHEN SUM(logical_reads) > 0
        THEN FLOAT(SUM(lbp_pages_found)) / FLOAT(SUM(logical_reads))
        ELSE FLOAT(0)
    END AS hit_ratio,
    CASE
        WHEN SUM(logical_reads) < 1
        THEN 0
        ELSE 1 - (CAST(SUM(logical_reads) AS decfloat) / COUNT(*)) / MAX(logical_reads)
    END                      AS access_skew,
    SUM(data_object_l_pages) AS data_object_l_pages,
    COUNT(*)                 AS num_members,
    CASE
        WHEN SUM(data_object_l_pages) < 1
        THEN 0
        ELSE 1 - (CAST(SUM(data_object_l_pages) AS decfloat) / COUNT(*)) / MAX(data_object_l_pages)
    END                       AS data_skew,
    SUM(index_object_l_pages) AS index_object_l_pages,
    SUM(xda_object_l_pages)   AS xda_object_l_pages,
    SUM(lob_object_l_pages)   AS lob_object_l_pages,
    SUM(long_object_l_pages)  AS long_object_l_pages,
    CASE
        WHEN (SUM(rows_read) + SUM(rows_inserted) + SUM(rows_updated) + SUM(rows_deleted)) = 0
        THEN DOUBLE(0)
        ELSE 100.0 * SUM(DOUBLE(rows_read)) / (SUM (DOUBLE(rows_read)) + SUM(DOUBLE(rows_inserted))
            + SUM(DOUBLE(rows_updated)) + SUM(DOUBLE(rows_deleted)))
    END                  AS rows_read_versus_accessed,
    SUM(page_reclaims_x) AS page_reclaims_x,
    SUM(page_reclaims_s) AS page_reclaims_s
FROM by_member
GROUP BY tabschema,
    tabname,
    tab_type
ORDER BY table_scans desc, rows_read desc, rows_inserted desc, rows_updated desc, rows_deleted desc;


-- Some index details
SELECT  OWNER, TABSCHEMA, TABNAME, INDSCHEMA, INDNAME, INDCARD, CREATE_TIME, STATS_TIME, LASTUSED, UNIQUERULE, INDEXTYPE, COLNAMES
FROM SYSCAT.INDEXES
WHERE 1 = 1
  --AND TABNAME IN ('')
  --AND  INDEXTYPE in ('DIM', 'BLOK')
AND TABSCHEMA NOT LIKE 'SYS%' AND TABSCHEMA NOT IN ('ASN','IBM_RTMON')
--AND UNIQUERULE NOT IN ('P','U')
--AND CREATE_TIME >= '2017-07-24'
ORDER BY CREATE_TIME DESC;


SELECT CREATE_TIME, OWNER, TABSCHEMA, TABNAME, INDSCHEMA, INDNAME, UNIQUERULE, INDEXTYPE, COLNAMES
FROM SYSCAT.INDEXES
WHERE 1 = 1 
  --AND  INDEXTYPE in ('DIM', 'BLOK')
AND TABSCHEMA NOT LIKE 'SYS%' AND TABSCHEMA NOT IN ('ASN','IBM_RTMON')
--AND UNIQUERULE NOT IN ('P','U')
--AND CREATE_TIME >= '2017-07-24'
ORDER BY CREATE_TIME DESC;

-- Verificar indices inválidos
WITH C AS (
select TABSCHEMA, TABNAME, INDSCHEMA, INDNAME, UNIQUERULE
from syscat.INDEXES 
WHERE 1 = 1
AND TABNAME in ()
)
SELECT T1.TABSCHEMA, T1.TABNAME, T1.INDSCHEMA, T1.INDNAME, T2.index_requires_rebuild, t1.UNIQUERULE
FROM C T1 INNER JOIN TABLE(SYSPROC.ADMIN_GET_INDEX_INFO('I',T1.INDSCHEMA, T1.INDNAME)) T2 
                  ON T1.TABSCHEMA = T2.TABSCHEMA 
                 AND T1.TABNAME = T2.TABNAME 
                 AND T1.INDSCHEMA = T2.INDSCHEMA 
                 AND T1.INDNAME = T2.INDNAME;


-- Query to get LOOGED column property 
SELECT        
        T1.TABSCHEMA, T1.TABNAME, T1.COLNAME||',' AS COLNAME, T1.TYPENAME, T1.LOGGED, T1.COLNO
FROM SYSCAT.COLUMNS T1
WHERE 1 = 1
--AND T1.TABSCHEMA = 'SYSIBMADM'
AND TABSCHEMA NOT LIKE 'SYS%' AND TABSCHEMA NOT IN ('IBM_RTMON')
AND T1.COLNAME = ''
--AND T1.TYPENAME LIKE '%LOB%'
--AND T1.TABNAME IN ('')
ORDER BY T1.COLNO
;

-- Simple query to retrieve all columns in a table with your respective data type and size
SELECT 
       T1.TABSCHEMA,
       T1.TABNAME,
       CASE
           WHEN TYPENAME IN ('REAL','DATE','TIMESTAMP','INTEGER','BIGINT','SMALLINT','CLOB','BLOB') THEN
                COLNAME || ' ' || TYPENAME || ','
           WHEN TYPENAME IN ('VARCHAR','CHARACTER') THEN
                COLNAME || ' ' || TYPENAME || '(' || LENGTH ||'),'
           WHEN TYPENAME = 'DECIMAL' THEN
                COLNAME || ' ' || TYPENAME || '(' || LENGTH ||','||SCALE ||'),'
       END CMD,       
       COLNAME ||',' AS COLNAME,
       COLNO,
       TYPENAME,
       TYPENAME,
       LENGTH,
       SCALE,
       T2.CARD
FROM SYSCAT.COLUMNS T1 INNER JOIN SYSCAT.TABLES T2 ON T1.TABSCHEMA = T2.TABSCHEMA AND T1.TABNAME = T2.TABNAME
WHERE 1 = 1
--AND T1.TABSCHEMA NOT LIKE 'SYS%'
--AND T2.TABSCHEMA = 'ASN'
--AND TYPENAME LIKE '%LOB%'
--and t1.colname = 'DATAPARTITIONS'
AND T1.TABNAME  = 'DATAPARTITIONS'
ORDER BY COLNO;

-- Obter informações de partição de tabela, como intervalo e a coluna envolvida
SELECT  
        T2.TABSCHEMA, T2.TABNAME,        
        (SELECT T.DATAPARTITIONEXPRESSION FROM SYSCAT.DATAPARTITIONEXPRESSION T WHERE T.TABSCHEMA = T2.TABSCHEMA AND T.TABNAME = T2.TABNAME) AS COLNAME,
        T2.DATAPARTITIONNAME,
        T2.CARD, T2.STATS_TIME, T2.LASTUSED,
        T2.LOWVALUE, T2.HIGHVALUE,
        T2.TBSPACEID,
        (SELECT T.TBSPACE FROM SYSCAT.TABLESPACES T WHERE T.TBSPACEID = T2.TBSPACEID) AS DATA_TBSPACE,
        (SELECT T.TBSPACE FROM SYSCAT.TABLESPACES T WHERE T.TBSPACEID = T2.INDEX_TBSPACEID) AS INDEX_TBSPACE,
        (SELECT T.TBSPACE FROM SYSCAT.TABLESPACES T WHERE T.TBSPACEID = T2.LONG_TBSPACEID) AS LONG_TBSPACE,
        (SELECT T.PAGESIZE FROM SYSCAT.TABLESPACES T WHERE T.TBSPACEID = T2.TBSPACEID) AS PAGESIZE,
        (SELECT T.EXTENTSIZE FROM SYSCAT.TABLESPACES T WHERE T.TBSPACEID = T2.TBSPACEID) AS EXTENTSIZE,
        T2.STATUS
FROM SYSCAT.DATAPARTITIONS T2 
WHERE 1 = 1
AND T2.TABSCHEMA NOT LIKE 'SYS%' AND T2.TABSCHEMA NOT IN ('ASN','IBM_RTMON','REP','DB2EXT','DB2INST1')
--AND T2.TABNAME IN ('')
--AND T2.TABSCHEMA = ''
--AND T2.DATAPARTITIONNAME <> 'PART0'
--AND T2.TABSCHEMA IN ('MLD','PCF')
ORDER BY LOWVALUE
WITH UR;
   
SELECT DISTINCT T2.TABSCHEMA, T2.TABNAME
FROM SYSCAT.DATAPARTITIONS T2 
WHERE 1 = 1
--AND T2.TABNAME IN ('')
--AND T2.TABSCHEMA = ''
AND T2.DATAPARTITIONNAME <> 'PART0'
AND T2.TABSCHEMA NOT LIKE 'SYS%'
WITH UR;   
   
-- Consulta para monitorar o progresso do ADMIN_MOVE_TABLE
WITH TBS (TABSCHEMA,TABNAME) AS (
                                SELECT DISTINCT VARCHAR(TABSCHEMA,12) AS TABSCHEMA, VARCHAR(TABNAME,60) AS TABNAME
                                  FROM SYSTOOLS.ADMIN_MOVE_TABLE 
                                 WHERE (KEY = 'STATUS' OR key = 'CLEANUP_END' or key = 'INIT_START' OR KEY = 'COPY_TOTAL_ROWS')
                              ORDER BY TABSCHEMA, TABNAME)
SELECT  TBS.TABSCHEMA, TBS.TABNAME, 
        (SELECT VARCHAR(SUBSTR(TIS.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIS WHERE TIS.KEY = 'COPY_TOTAL_ROWS' AND TIS.TABSCHEMA = TBS.TABSCHEMA AND TIS.TABNAME = TBS.TABNAME) AS COPY_TOTAL_ROWS,
        (SELECT VARCHAR(SUBSTR(TIS.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIS WHERE TIS.KEY = 'REPLAY_TOTAL_ROWS' AND TIS.TABSCHEMA = TBS.TABSCHEMA AND TIS.TABNAME = TBS.TABNAME) AS REPLAY_TOTAL_ROWS,
        (SELECT VARCHAR(SUBSTR(TIS.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIS WHERE TIS.KEY = 'STATUS' AND TIS.TABSCHEMA = TBS.TABSCHEMA AND TIS.TABNAME = TBS.TABNAME) AS STATUS,
        TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'INIT_START' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME)) AS START,
        TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'CLEANUP_END' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME)) AS END,
        TIMESTAMPDIFF(4, CHAR(TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'CLEANUP_END' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME)) - TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'INIT_START' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME)))) ||  'min'
        || (TIMESTAMPDIFF(2, CHAR(TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'CLEANUP_END' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME)) - TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'INIT_START' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME)))) - 
        (TIMESTAMPDIFF(4, CHAR(TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'CLEANUP_END' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME)) - TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'INIT_START' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME))))*60)) || 'seg' AS DIFF
        ,(TIMESTAMPDIFF(2, CHAR(TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'CLEANUP_END' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME)) - TIMESTAMP((SELECT VARCHAR(SUBSTR(TIE.VALUE, 1, 50), 50) VALUE FROM SYSTOOLS.ADMIN_MOVE_TABLE TIE WHERE TIE.KEY = 'INIT_START' AND TIE.TABSCHEMA = TBS.TABSCHEMA AND TIE.TABNAME = TBS.TABNAME))))) AS TOTAL_SECONDS
        ,'CALL SYSPROC.ADMIN_MOVE_TABLE('''||TRIM(TABSCHEMA)||''','''|| TRIM(TABNAME)||''','||''''||TRIM(TABSCHEMA)||'TBS08K'','||''''||TRIM(TABSCHEMA)||'TBS08K'','||''''||TRIM(TABSCHEMA)||'TBS08K'','''','''','''','''',''COPY_USE_LOAD COPY YES TO /db2/db2inst1/media_hadr'',''CANCEL'');' AS CANCELAR_MOVE_TABLE
FROM TBS
--where TABschema = ''
--and status = 'REPLAY'
ORDER BY START desc;
    
-- Identity Definitions
SELECT C.TBCREATOR,
    C.TBNAME,
    C.NAME,
    S.START,
    S.INCREMENT,
    S.MINVALUE,
    S.MAXVALUE,
    S.CYCLE,
    S.CACHE,
    S.ORDER,
    S.SEQID,
    S.LASTASSIGNEDVAL
    --,'ALTER TABLE '||TRIM(c.TBCREATOR)||'.'||c.TBNAME||' ALTER COLUMN '||c.NAME||' SET CACHE '||S.CACHE||';' AS CMD
FROM SYSIBM.SYSCOLUMNS     AS C,
    SYSIBM.SYSDEPENDENCIES AS D,
    SYSIBM.SYSSEQUENCES    AS S
WHERE C.TBCREATOR = D.DSCHEMA
    AND C.TBNAME = D.DNAME
    AND D.BNAME = S.SEQNAME
    AND D.BSCHEMA = S.SEQSCHEMA
    AND C.IDENTITY = 'Y'
    AND D.DTYPE = 'T'
    AND D.BTYPE = 'Q'
    AND S.SEQTYPE = 'I'
    AND C.TBCREATOR = ''
    AND C.TBCREATOR NOT LIKE 'SYS%'
    WITH UR;


-- Drop identity and recreate identity
SELECT 
'ALTER TABLE '||TRIM(TABSCHEMA)||'.'||TRIM(TABNAME)||' ALTER COLUMN '||TRIM(COLNAME)||' DROP IDENTITY;',
'CALL DBSYS.SETIDENTITYALWAYS ('''||TRIM(TABSCHEMA)||''','''||TRIM(TABNAME)||''','''||TRIM(COLNAME)||''');'
FROM SYSCAT.COLUMNS 
WHERE TABSCHEMA = ''
--AND LOGGED = 'N'
--AND GENERATED IN ('A','D')
AND IDENTITY = 'Y';

SELECT --T1.TABSCHEMA, T1.TABNAME, T1.GENERATED, T2.CARD,
  'db2 "DECLARE CURSOR_'||TRIM(T2.TABNAME)||' CURSOR DATABASE MNTP USER db2inst1 USING xxxxxxxx FOR SELECT * FROM '||TRIM(T2.TABSCHEMA)||'.'||TRIM(T2.TABNAME)||' WITH UR"'
  ||CHR(13)||
   CASE WHEN T1.GENERATED = 'A' THEN 
   'db2 "LOAD FROM CURSOR_'||TRIM(T2.TABNAME)||' OF CURSOR MODIFIED BY IDENTITYOVERRIDE MESSAGES $vmsgoutdir/_'|| TRIM(T2.TABNAME) ||'.msg REPLACE INTO '||TRIM(T2.TABSCHEMA)||'.'||TRIM(T2.TABNAME)||' NONRECOVERABLE"'
   ||chr(10)
   ELSE 
   'db2 "LOAD FROM CURSOR_'||TRIM(T2.TABNAME)||' OF CURSOR MESSAGES $vmsgoutdir/_'|| TRIM(T2.TABNAME) ||'.msg REPLACE INTO '||TRIM(T2.TABSCHEMA)||'.'||TRIM(T2.TABNAME)||' NONRECOVERABLE"'
   ||chr(10)
  END CMD
FROM SYSCAT.COLUMNS T1 INNER JOIN SYSCAT.TABLES T2 ON (T1.TABSCHEMA = T2.TABSCHEMA AND T1.TABNAME = T2.TABNAME)
WHERE T1.TABSCHEMA = ''
--AND GENERATED IN ('A','D')
AND T1.TABNAME  IN ('')
AND T1.IDENTITY = 'Y';

ALTER TABLE DBA.DATABASESIZE_NEW_2 ALTER COLUMN UPDATEID SET GENERATED ALWAYS AS IDENTITY;

ALTER TABLE DBA.DATABASESIZE_NEW ALTER COLUMN UPDATEID DROP IDENTITY;

ALTER TABLE DBA.DATABASESIZE_NEW ALTER COLUMN SIZE_MB DROP NOT NULL