SELECT VARCHAR(OWNER, 10) OWNER,
	   VARCHAR(INDSCHEMA, 20) INDSCHEMA,
	   VARCHAR(INDNAME, 35) INDNAME,
	   VARCHAR(TABSCHEMA, 20) TABSCHEMA,
	   VARCHAR(TABNAME, 30) TABNAME,
	   LASTUSED,
	   CREATE_TIME,
	   STATS_TIME
FROM SYSCAT.INDEXES
WHERE TABNAME = ''
ORDER BY CREATE_TIME;

WITH X AS (SELECT TRIM(MGI.TABSCHEMA)                   TABSCHEMA,
                  MGI.TABNAME                           TABNAME,
                  TRIM(I.INDSCHEMA)                     INDSCHEMA,
                  I.INDNAME                             INDNAME,
                  SUM(MGI.INDEX_SCANS)                  SOMASCANS,
                  SUM(MGI.PAGE_ALLOCATIONS*TS.PAGESIZE) QTDBYTES,
                  I.COLNAMES                            COLNAMES
           FROM TABLE(MON_GET_INDEX(NULL,NULL, -2)) MGI INNER JOIN SYSCAT.TABLES          T   ON MGI.TABSCHEMA = T.TABSCHEMA  AND MGI.TABNAME = T.TABNAME
                                                        INNER JOIN SYSCAT.INDEXES         I   ON MGI.TABSCHEMA = I.TABSCHEMA  AND MGI.TABNAME = I.TABNAME AND MGI.IID = I.IID
                                                        INNER JOIN SYSCAT.TABLESPACES     TS  ON I.TBSPACEID   = TS.TBSPACEID
                         AND I.INDNAME NOT LIKE 'PK%'
                         AND I.INDNAME NOT LIKE 'AK%'
                         AND I.INDNAME NOT LIKE 'UK%'
                         AND I.INDNAME NOT LIKE 'SQL%'
                         AND MGI.TABSCHEMA NOT LIKE '%SYS%'
           GROUP BY TRIM(MGI.TABSCHEMA),
                    MGI.TABNAME,
                    TRIM(I.INDSCHEMA),
                    I.INDNAME,
                    I.COLNAMES
           UNION ALL             
           SELECT TRIM(MGI.TABSCHEMA)                   TABSCHEMA,
                  MGI.TABNAME                           TABNAME,
                  TRIM(I.INDSCHEMA)                     INDSCHEMA,
                  I.INDNAME                             INDNAME,
                  SUM(MGI.INDEX_SCANS)                  SOMASCANS,
                  SUM(MGI.PAGE_ALLOCATIONS*TS.PAGESIZE) QTDBYTES,
                  I.COLNAMES                            COLNAMES
           FROM TABLE(MON_GET_INDEX(NULL,NULL, -2)) MGI INNER JOIN SYSCAT.TABLES          T   ON MGI.TABSCHEMA = T.TABSCHEMA  AND MGI.TABNAME = T.TABNAME
                                                        INNER JOIN SYSCAT.INDEXES         I   ON MGI.TABSCHEMA = I.TABSCHEMA  AND MGI.TABNAME = I.TABNAME AND MGI.IID = I.IID
                                                        INNER JOIN SYSCAT.INDEXPARTITIONS IP  ON I.INDSCHEMA   = IP.INDSCHEMA AND I.INDNAME   = IP.INDNAME
                                                        INNER JOIN SYSCAT.TABLESPACES     TS  ON IP.INDPARTITIONTBSPACEID = TS.TBSPACEID
                         AND I.INDNAME NOT LIKE 'PK%'
                         AND I.INDNAME NOT LIKE 'AK%'
                         AND I.INDNAME NOT LIKE 'UK%'
                         AND I.INDNAME NOT LIKE 'SQL%'
                         AND MGI.TABSCHEMA NOT LIKE '%SYS%'
           GROUP BY TRIM(MGI.TABSCHEMA),
                    MGI.TABNAME,
                    TRIM(I.INDSCHEMA),
                    I.INDNAME,
                    I.COLNAMES)
SELECT * FROM X ORDER BY SOMASCANS ASC;