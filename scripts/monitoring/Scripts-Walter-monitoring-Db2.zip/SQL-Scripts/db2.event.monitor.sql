-- TO VERIFY THE CREATION OF THE EVENT MONITOR:
SELECT EM.EVMONNAME
    ,EVENT_MON_STATE(EM.EVMONNAME) AS ESTADO
    ,EM.OWNER
    ,EM.TARGET
    ,EM.MAXFILES
    ,EM.MAXFILESIZE
    ,EM.BUFFERSIZE
    ,EM.IO_MODE
    ,EM.WRITE_MODE
    ,EM.AUTOSTART
    ,EM.MONSCOPE
    ,EM.EVMON_ACTIVATES
FROM SYSCAT.EVENTMONITORS EM; 

DROP EVENT monitor VIWPESSOA;

--create and activate statements event monitor
CREATE EVENT MONITOR DB2_DETAIL_STATEMENT FOR STATEMENTS WRITE TO FILE '/db2/db2inst1/failarch/event_monitor' MANUALSTART MAXFILES 30 MAXFILESIZE 10240 BUFFERSIZE 32 NONBLOCKED REPLACE; 
    
-- 1 Indicates that the specified event monitor should be activated. 
-- 0 Indicates that the specified event monitor will be deactivated. 
-- The event monitor should not already be active; otherwise a warning (SQLSTATE 01598) is issued.
SET EVENT MONITOR "DB2_MONITORA_STATEMENTS" STATE = 1;

-- When an event monitor is flushed, its active internal buffers are written to the event monitor output object.
-- Because some events do not happen as frequently as others, it may be desirable to force an event monitor to collect monitor data and write it to its target location before a monitor triggering event takes place.
-- In such situations, an event monitor can be made to collect information early by executing the FLUSH EVENT MONITOR SQL statement.
FLUSH EVENT MONITOR DB2DETAILSTATEMENT;

-- Viewing Event Monitor Data
-- db database-alias specifies the database whose data is to be displayed. This parameter is case sensitive.
-- evm event-monitor-name the one-part name of the event monitor. An ordinary or delimited SQL identifier. This parameter is case sensitive.
-- path event-monitor-target specifies the directory containing the eventmonitor trace files.
-- db2evmon -db database-alias -evm event-monitor-name
-- or
-- db2evmon -path event-monitor-target
-- Example:
db2evmon -db cli_tbp -evm DB2_MONITOR_STATEMENTS > evtmon_STATEMENTS.out

--0 - Indicates that the specified event monitor should be deactivated.
SET EVENT MONITOR "DB2DETAILSTATEMENT" STATE = 0

-- Dropping an event monitor
--Drop event monitor event-monitor-name
-- Example:
drop event monitor DB2_MONITORA_STATEMENTS


---------------------------------------- 
==================================================================================================
-- TRACE
==================================================================================================
>>> PREPARAÇÃO DO TRACE: 
 
mkdir -p /db2/db2inst1/failarch/trace/statements
mkdir -p /db2/db2inst1/failarch/TRACE/CONNECTIONS
mkdir -p /db2/db2inst1/failarch/TRACE/TRANSACTIONS
mkdir -p /db2/db2inst1/failarch/TRACE/DEADLOCKS


 
db2 CONNECT TO LIFERAY 
db2 "SELECT EM.EVMONNAME, EVENT_MON_STATE(EVMONNAME) AS STATE  FROM SYSCAT.EVENTMONITORS AS EM" 
 
vi 01_CREATE_EVENT_MONITOR.sql						  
CREATE EVENT MONITOR DB2_MONITOR_STATEMENTS FOR STATEMENTS WRITE TO FILE '/db2/db2inst1/failarch/trace/STATEMENTS' MANUALSTART MAXFILESIZE 128000 BUFFERSIZE 32  NONBLOCKED REPLACE; 
CREATE EVENT MONITOR DB2_MONITORA_CONNECTION FOR CONNECTIONS WRITE TO FILE '/db2/db2inst1/failarch/TRACE/CONNECTIONS' MANUALSTART MAXFILESIZE 128000 BUFFERSIZE 32  NONBLOCKED REPLACE; 
CREATE EVENT MONITOR DB2_MONITORA_TRANSACTIONS FOR TRANSACTIONS WRITE TO FILE '/db2/db2inst1/failarch/TRACE/TRANSACTIONS' MANUALSTART MAXFILESIZE 128000 BUFFERSIZE 32  NONBLOCKED REPLACE; 
CREATE EVENT MONITOR DB2_MONITORA_DEADLOCKS FOR DEADLOCKS WRITE TO FILE '/db2/db2inst1/failarch/TRACE/DEADLOCKS' MANUALSTART MAXFILESIZE 128000 BUFFERSIZE 32  NONBLOCKED REPLACE; 

drop event monitor DB2_MONITOR_STATEMENTS;

vi 02_START_EVENT_MONITOR.sql
SET EVENT MONITOR DB2_MONITOR_STATEMENTS STATE = 1; 
SET EVENT MONITOR DB2_MONITORA_CONNECTION STATE = 1; 
SET EVENT MONITOR DB2_MONITORA_TRANSACTIONS STATE = 1; 
SET EVENT MONITOR DB2_MONITORA_DEADLOCKS STATE = 1; 

vi 03_STOP_EVENT_MONITOR.sql
SET EVENT MONITOR DB2_MONITOR_STATEMENTS STATE = 0; 
SET EVENT MONITOR DB2_MONITORA_CONNECTION STATE = 0; 
SET EVENT MONITOR DB2_MONITORA_TRANSACTIONS STATE = 0; 
SET EVENT MONITOR DB2_MONITORA_DEADLOCKS STATE = 0;  

chmod 750 01_CREATE_EVENT_MONITOR.sql 02_START_EVENT_MONITOR.sql 03_STOP_EVENT_MONITOR.sql


>> CRIAR O EVENT MONITOR

cd /db2/db2inst1/failarch/TRACE/
./01_CREATE_EVENT_MONITOR.sql |tee 01_CREATE_EVENT_MONITOR.out

db2 "SELECT EM.EVMONNAME, EVENT_MON_STATE(EVMONNAME) AS STATE  FROM SYSCAT.EVENTMONITORS AS EM" 

>>> ATIVAR 


cd /db2/db2inst1/failarch/TRACE/
./02_START_EVENT_MONITOR.sql |tee 02_START_EVENT_MONITOR.out
db2 connect to liferay
db2 "SELECT EM.EVMONNAME, EVENT_MON_STATE(EVMONNAME) AS STATE  FROM SYSCAT.EVENTMONITORS AS EM" 

>>> DESATIVAR


cd /db2/db2inst1/failarch/TRACE/
./03_STOP_EVENT_MONITOR.sql |tee 03_STOP_EVENT_MONITOR.out
db2 "SELECT EM.EVMONNAME, EVENT_MON_STATE(EVMONNAME) AS STATE  FROM SYSCAT.EVENTMONITORS AS EM" 
 
>>> NO LINUX: 
 
cd /db2/db2inst1/failarch/TRACE
 
--db2evmon -path /db2/db2inst1/failarch/TRACE/STATEMENTS > /db2/db2inst1/failarch/TRACE/evtmon_STATEMENTS.out
--db2evmon -path /db2/db2inst1/failarch/TRACE/CONNECTIONS > /db2/db2inst1/failarch/TRACE/evtmon_CONNECTIONS.out 
--db2evmon -path /db2/db2inst1/failarch/TRACE/TRANSACTIONS > /db2/db2inst1/failarch/TRACE/evtmon_TRANSACTIONS.out 
--db2evmon -path /db2/db2inst1/failarch/TRACE/DEADLOCKS > /db2/db2inst1/failarch/TRACE/evtmon_DEADLOCKS.out 