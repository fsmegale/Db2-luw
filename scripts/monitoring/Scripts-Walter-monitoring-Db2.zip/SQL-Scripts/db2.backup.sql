-- Check backup status
SELECT
    VARCHAR(S.UTILITY_DBNAME,10) AS DBNAME,
    P.PROGRESS_START_TIME AS START_TIME,
    VARCHAR(S.UTILITY_TYPE,15) AS TIPO,
    S.UTILITY_PRIORITY AS PRIORIDADE,
    S.UTILITY_DESCRIPTION AS DESCRICAO,
    DECIMAL(P.PROGRESS_TOTAL_UNITS / 1024 / 1024.,14,2) AS PROGRESS_TOTAL_MB,
    DECIMAL(P.PROGRESS_COMPLETED_UNITS / 1024 / 1024.,14,2) AS PROGRESS_COMPLETED_MB,    
    SMALLINT((FLOAT(P.PROGRESS_COMPLETED_UNITS) / FLOAT(P.PROGRESS_TOTAL_UNITS)) * 100) ||'%' PERCENT_COMPLETE,
    TIMESTAMPDIFF(4,CHAR((CURRENT TIMESTAMP)-TIMESTAMP(PROGRESS_START_TIME))) AS "ELAPSED TIME (MIN)",
    --(P.PROGRESS_TOTAL_UNITS * (TIMESTAMPDIFF(4,CHAR((CURRENT TIMESTAMP)-TIMESTAMP(PROGRESS_START_TIME))))) / PROGRESS_COMPLETED_UNITS
    VARCHAR(TO_CHAR(P.PROGRESS_START_TIME  + ((P.PROGRESS_TOTAL_UNITS * (TIMESTAMPDIFF(4,CHAR((CURRENT TIMESTAMP)-TIMESTAMP(PROGRESS_START_TIME))))) / PROGRESS_COMPLETED_UNITS) MINUTES, 'DD/MM/YYYY HH24:MI:SS'),20) AS PREVISAO_TERMINO
 FROM SYSIBMADM.SNAPUTIL_PROGRESS AS P INNER JOIN SYSIBMADM.SNAPUTIL AS S ON P.UTILITY_ID = S.UTILITY_ID
ORDER BY S.UTILITY_DBNAME;

-- Load utilities monitoring
SELECT VARCHAR(S.UTILITY_DBNAME, 10) AS DBNAME,
    P.PROGRESS_START_TIME            AS INICIO,
    P.UTILITY_STATE                  AS ESTADO,
    P.PROGRESS_DESCRIPTION           AS FASE,
    VARCHAR(S.UTILITY_TYPE, 15)      AS TIPO,
    CASE
        WHEN P.PROGRESS_TOTAL_UNITS = P.PROGRESS_COMPLETED_UNITS
        THEN 'COMPLETED'
        WHEN PROGRESS_COMPLETED_UNITS > 0
        THEN VARCHAR(TO_CHAR(P.PROGRESS_START_TIME + ((P.PROGRESS_TOTAL_UNITS * (TIMESTAMPDIFF(4,
            CHAR((CURRENT TIMESTAMP)-TIMESTAMP(PROGRESS_START_TIME))))) / PROGRESS_COMPLETED_UNITS)
            MINUTES, 'DD/MM/YYYY HH24:MI:SS'), 20)
        ELSE 'EM ANDAMENTO'
    END STATUS,
    CASE
        WHEN PROGRESS_TOTAL_UNITS > 0
        THEN ROUND(PROGRESS_COMPLETED_UNITS*100/PROGRESS_TOTAL_UNITS, 2)
        ELSE 0
    END                          AS PERCENTUAL,
    P.PROGRESS_TOTAL_UNITS       AS TOTAL,
    P.PROGRESS_COMPLETED_UNITS   AS COMPLETADO,
    S.UTILITY_DESCRIPTION        AS DESCRICAO
 FROM SYSIBMADM.SNAPUTIL_PROGRESS AS P
INNER JOIN SYSIBMADM.SNAPUTIL    AS S
   ON  P.UTILITY_ID = S.UTILITY_ID
--WHERE P.PROGRESS_TOTAL_UNITS <> 0
ORDER BY P.PROGRESS_START_TIME DESC;

-- Backup history
SELECT  DISTINCT (SELECT VARCHAR(REPLACE(HOST_NAME,'.sicoob.com.br',''),10) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,
        START_TIME,
        VARCHAR(CURRENT SERVER,9) DBNAME,
  CASE OPERATION
                WHEN 'A' THEN 'Create table space'
                WHEN 'B' THEN 'Backup'
                WHEN 'C' THEN 'Load copy'
                WHEN 'D' THEN 'Dropped table'
                WHEN 'F' THEN 'Roll forward'
                WHEN 'G' THEN 'Reorganize table'
                WHEN 'L' THEN 'Load'
                WHEN 'N' THEN 'Rename table space'
                WHEN 'O' THEN 'Drop table space'
                WHEN 'Q' THEN 'Quiesce'
                WHEN 'R' THEN 'Restore'
                WHEN 'T' THEN 'Alter table space'
                WHEN 'U' THEN 'Unload'
                WHEN 'X' THEN 'Archive log'
   END AS OPERATION,
   CASE 
                WHEN OPERATION ='X' AND OPERATIONTYPE = 'P' THEN 'Primary log path'
                WHEN OPERATION ='X' AND OPERATIONTYPE = 'M' THEN 'Secondary (mirror) log path'
                WHEN OPERATION ='X' AND OPERATIONTYPE = 'F' THEN 'Failover archive path'
                WHEN OPERATION ='X' AND OPERATIONTYPE = '1' THEN 'Primary log archive method'
                WHEN OPERATION ='X' AND OPERATIONTYPE = '2' THEN 'Secondary log archive method'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'F' THEN 'Offline'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'N' THEN 'Online'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'I' THEN 'Incremental offline'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'O' THEN 'Incremental online'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'D' THEN 'Delta offline'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'E' THEN 'Delta online'
                WHEN OPERATION ='F' AND OPERATIONTYPE = 'E' THEN 'End of logs'
                WHEN OPERATION ='F' AND OPERATIONTYPE = 'P' THEN 'Point in time'
                WHEN OPERATION ='L' AND OPERATIONTYPE = 'I' THEN 'Insert'
                WHEN OPERATION ='L' AND OPERATIONTYPE = 'R' THEN 'Replace'
                WHEN OPERATION ='T' AND OPERATIONTYPE = 'C' THEN 'Add containers'
                WHEN OPERATION ='T' AND OPERATIONTYPE = 'R' THEN 'Rebalance'
                WHEN OPERATION ='Q' AND OPERATIONTYPE = 'S' THEN 'Quiesce share'
                WHEN OPERATION ='Q' AND OPERATIONTYPE = 'U' THEN 'Quiesce update'
                WHEN OPERATION ='Q' AND OPERATIONTYPE = 'X' THEN 'Quiesce exclusive'
                WHEN OPERATION ='Q' AND OPERATIONTYPE = 'Z' THEN 'Quiesce reset'
   END AS OPERATIONTYPE,
   CASE DEVICETYPE 
        WHEN 'A' THEN 'TSM'
        WHEN 'C' THEN 'client'
        WHEN 'D' THEN 'disk'
        WHEN 'F' THEN 'snapshot backup'
        WHEN 'K' THEN 'diskette'
        WHEN 'L' THEN 'local'
        WHEN 'N' THEN 'generated internally by DB2®'
        WHEN 'O' THEN 'other (for other vendor device support)'
        WHEN 'P' THEN 'pipe'
        WHEN 'Q' THEN 'cursor'
        WHEN 'R' THEN 'remote fetch data'
        WHEN 'S' THEN 'server'
        WHEN 'T' THEN 'tape'
        WHEN 'U' THEN 'user exit'
        WHEN 'X' THEN 'X/Open XBSA interface'
   END DEVICETYPE,
   --firstlog, lastlog,
   VARCHAR(DATE(TIMESTAMP(START_TIME)) ||' '|| TIME(TIMESTAMP(START_TIME)),21) AS "Begin Time",
   VARCHAR(DATE(TIMESTAMP(END_TIME)) ||' '|| TIME(TIMESTAMP(END_TIME)),21) AS "End Time", 
   TIMESTAMPDIFF(4,CHAR(TIMESTAMP(END_TIME)-TIMESTAMP(START_TIME))) AS "Elapsed Time (Min)",
   TIMESTAMPDIFF(8,CHAR(TIMESTAMP(END_TIME)-TIMESTAMP(START_TIME))) AS "Elapsed Time (Hours)",
   TIMESTAMPDIFF(16,CHAR(TIMESTAMP(END_TIME)-TIMESTAMP(START_TIME))) AS "Elapsed Time (Days)",
   --abs(end_time - (LEAD(end_time, 1) OVER (order by end_time desc))) as "Time for archive",
   SQLCODE
FROM TABLE(SYSPROC.ADMIN_LIST_HIST())
  WHERE 
  OPERATION = 'B'
  --AND SQLCODE IS NULL
  --Listar o último backup 
  --AND date(timestamp(start_time)) IN (select max(date(timestamp(start_time))) FROM SYSIBMADM.DB_HISTORY where OPERATION = 'B' AND DEVICETYPE = 'A' AND SQLCODE IS NULL with ur)
ORDER BY "End Time" DESC WITH UR;

-- Log archive history
SELECT  DISTINCT (SELECT VARCHAR(HOST_NAME,9) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,
        START_TIME,
        VARCHAR(CURRENT SERVER,9) DBNAME,
  CASE OPERATION
                WHEN 'A' THEN 'Create table space'
                WHEN 'B' THEN 'Backup'
                WHEN 'C' THEN 'Load copy'
                WHEN 'D' THEN 'Dropped table'
                WHEN 'F' THEN 'Roll forward'
                WHEN 'G' THEN 'Reorganize table'
                WHEN 'L' THEN 'Load'
                WHEN 'N' THEN 'Rename table space'
                WHEN 'O' THEN 'Drop table space'
                WHEN 'Q' THEN 'Quiesce'
                WHEN 'R' THEN 'Restore'
                WHEN 'T' THEN 'Alter table space'
                WHEN 'U' THEN 'Unload'
                WHEN 'X' THEN 'Archive log'
   END AS OPERATION,   
   CASE 
                WHEN OPERATION ='X' AND OPERATIONTYPE = 'P' THEN 'Primary log path'
                WHEN OPERATION ='X' AND OPERATIONTYPE = 'M' THEN 'Secondary (mirror) log path'
                WHEN OPERATION ='X' AND OPERATIONTYPE = 'F' THEN 'Failover archive path'
                WHEN OPERATION ='X' AND OPERATIONTYPE = '1' THEN 'Primary log archive method'
                WHEN OPERATION ='X' AND OPERATIONTYPE = '2' THEN 'Secondary log archive method'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'F' THEN 'Offline'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'N' THEN 'Online'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'I' THEN 'Incremental offline'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'O' THEN 'Incremental online'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'D' THEN 'Delta offline'
                WHEN OPERATION ='B' AND OPERATIONTYPE = 'E' THEN 'Delta online'
                WHEN OPERATION ='F' AND OPERATIONTYPE = 'E' THEN 'End of logs'
                WHEN OPERATION ='F' AND OPERATIONTYPE = 'P' THEN 'Point in time'
                WHEN OPERATION ='L' AND OPERATIONTYPE = 'I' THEN 'Insert'
                WHEN OPERATION ='L' AND OPERATIONTYPE = 'R' THEN 'Replace'
                WHEN OPERATION ='T' AND OPERATIONTYPE = 'C' THEN 'Add containers'
                WHEN OPERATION ='T' AND OPERATIONTYPE = 'R' THEN 'Rebalance'
                WHEN OPERATION ='Q' AND OPERATIONTYPE = 'S' THEN 'Quiesce share'
                WHEN OPERATION ='Q' AND OPERATIONTYPE = 'U' THEN 'Quiesce update'
                WHEN OPERATION ='Q' AND OPERATIONTYPE = 'X' THEN 'Quiesce exclusive'
                WHEN OPERATION ='Q' AND OPERATIONTYPE = 'Z' THEN 'Quiesce reset'
   END AS OPERATIONTYPE,
   CASE DEVICETYPE 
        WHEN 'A' THEN 'TSM'
        WHEN 'C' THEN 'client'
        WHEN 'D' THEN 'disk'
        WHEN 'F' THEN 'snapshot backup'
        WHEN 'K' THEN 'diskette'
        WHEN 'L' THEN 'local'
        WHEN 'N' THEN 'generated internally by DB2®'
        WHEN 'O' THEN 'other (for other vendor device support)'
        WHEN 'P' THEN 'pipe'
        WHEN 'Q' THEN 'cursor'
        WHEN 'R' THEN 'remote fetch data'
        WHEN 'S' THEN 'server'
        WHEN 'T' THEN 'tape'
        WHEN 'U' THEN 'user exit'
        WHEN 'X' THEN 'X/Open XBSA interface'
   END DEVICETYPE,
   FIRSTLOG, REPLACE(SUBSTR(FIRSTLOG,3),'.LOG'), LASTLOG,
   VARCHAR(DATE(TIMESTAMP(START_TIME)) ||' '|| TIME(TIMESTAMP(START_TIME)),21) AS "Begin Time",
   VARCHAR(DATE(TIMESTAMP(END_TIME)) ||' '|| TIME(TIMESTAMP(END_TIME)),21) AS "End Time",   
   SQLCODE
 FROM TABLE(SYSPROC.ADMIN_LIST_HIST())
WHERE OPERATION = 'X'
  AND TIMESTAMP(START_TIME) >= CURRENT DATE - 2 DAYS
ORDER BY FIRSTLOG DESC, "End Time" DESC WITH UR;

-- Log archive by hour
WITH ARCH AS 
      (
      SELECT  
                DATE(TIMESTAMP(END_TIME)) DATA,
                (SELECT VARCHAR(HOST_NAME,9) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR, 
                VARCHAR(CURRENT SERVER,9) DBNAME,
                YEAR(TIMESTAMP(END_TIME)) ANO,
                MONTH(TIMESTAMP(END_TIME))MES,
                DAY(TIMESTAMP(END_TIME)) DIA,
                DAYNAME(TIMESTAMP(END_TIME)) NOME_DIA,
                HOUR(TIME(TIMESTAMP(END_TIME))) HORA
        FROM SYSIBMADM.DB_HISTORY
       WHERE OPERATION = 'X'
         AND OPERATIONTYPE = '1'
         AND SQLCODE IS NULL
         AND END_TIME >= CURRENT TIMESTAMP - 120 DAY
    ORDER BY  ANO DESC, MES DESC, DIA, HORA DESC
        WITH UR
        )
  SELECT  DATA, SERVIDOR, DBNAME, ANO, MES, DIA, NOME_DIA , HORA, COUNT(*) QTD_Log_Archives
    FROM  ARCH
   WHERE 1 = 1
   --WHERE HORA BETWEEN 7 AND 15
   --AND NOME_DIA IN ('Sunday','Monday')
GROUP BY  DATA, SERVIDOR, DBNAME, ANO, MES, DIA, NOME_DIA, HORA
ORDER BY  ANO DESC, MES DESC, DIA DESC, HORA DESC FETCH FIRST 500 ROWS ONLY WITH UR;

-- Log archive by day
WITH ARCH AS 
      (
      SELECT  
                date(timestamp(end_time)) DATA,
                (SELECT VARCHAR(HOST_NAME,9) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR, 
                VARCHAR(CURRENT SERVER,9) DBNAME,
                YEAR(TIMESTAMP(END_TIME)) ANO,
                MONTH(TIMESTAMP(END_TIME))MES,
                DAY(TIMESTAMP(END_TIME)) DIA               
        FROM SYSIBMADM.DB_HISTORY
       WHERE OPERATION = 'X'
         AND OPERATIONTYPE = '1'
         AND SQLCODE IS NULL
         AND END_TIME >= CURRENT TIMESTAMP - 30 DAY
    ORDER BY  ANO DESC, MES DESC, DIA
        )
  SELECT  DATA, SERVIDOR, DBNAME, ANO, MES, DIA, COUNT(*) QTD_Log_Archives
    FROM  ARCH
--   WHERE HORA BETWEEN 2 AND 2
GROUP BY  DATA, SERVIDOR, DBNAME, ANO, MES, DIA
ORDER BY  ANO DESC, MES DESC, DIA DESC FETCH FIRST 500 ROWS ONLY WITH UR;

-- Average log archive by hour
WITH ARCH AS 
      (
      SELECT  
                date(timestamp(end_time)) DATA,
                (SELECT VARCHAR(HOST_NAME,9) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR, 
                VARCHAR(CURRENT SERVER,9) DBNAME,
                YEAR(TIMESTAMP(END_TIME)) ANO,
                MONTH(TIMESTAMP(END_TIME))MES,
                DAY(TIMESTAMP(END_TIME)) DIA
                --,HOUR(TIME(TIMESTAMP(END_TIME))) HORA
        FROM SYSIBMADM.DB_HISTORY
       WHERE OPERATION = 'X'
         AND OPERATIONTYPE = '1'
         AND SQLCODE IS NULL
         AND END_TIME >= CURRENT TIMESTAMP - 120 DAY
    ORDER BY  ANO DESC, MES DESC, DIA--, HORA DESC
        WITH UR
        )
  SELECT  DATA, SERVIDOR, DBNAME, ANO, MES, DIA, COUNT(*) AS QTD_Log_Archives, DECIMAL(COUNT(*) / 24.,14,2) AS MEDIA_POR_HORA
    FROM  ARCH
--   WHERE HORA BETWEEN 2 AND 2
GROUP BY  DATA, SERVIDOR, DBNAME, ANO, MES, DIA
ORDER BY  ANO DESC, MES DESC, DIA DESC FETCH FIRST 500 ROWS ONLY WITH UR;