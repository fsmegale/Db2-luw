#!/bin/bash
#**************************************************************************************************
#
#       Autor: Walter Flavio
#       Data: 10/05/2018
#       Versao 1.0 --> Criacao
#
#       Descricao:
#               Script que coleta dados do tamanho das tabelas de cada banco de dados DB2
#               do ambiente de producao.
#
#
#	Log de Revisao:
#		Use esta area para registrar alteracoes no script assim mantendo um historico de contribuicoes
#	Data:24/04/2017
#
#	Dependencias:
#               -> N/A
#
#**************************************************************************************************
# Carregar as variaveis do DB2
. $HOME/sqllib/db2profile
export PATH=$PATH:/home/db2inst1/sqllib/bin

###########################################################
############# Inicio Declaravao de variaveis ##############
###########################################################
# Dados para conexao na base $vdb, base repositorio WR - Workload Repository
vdb=db2reptr
vuser=xxxxxxx
vpws=xxxxxxx
vlockdir=/tmp/lockdir

this_pgm=GetTableSize
wr_report_dir=/db2/db2inst1/db2reptr/data1/dbwr_logs_table
out_dir=$wr_report_dir/$this_pgm.rpt         # Report directory
rpt_retained=99
warning=false
status=0

vdbexceptlist='DB2REPTR|GED_OLD|ARCHIVE|ARCHCOMP|STADV|TRAVELER|STPS|STMS|STSC|WIKIS|OPNACT|SNCOMM|METRICS|FEBDB|COGNOS|BLOGS|FILES|CONCORD|MOBILE|PEOPLEDB|DOGEAR|HOMEPAGE|FORUM|COGNOS|BDICC|BDCEGCD|BDCFGICC|BDFSM|BDFNMAIL|BDCE|BDIER|BDCN|BDPE|COOP_TCF|STG_20|DSMDB|REPDBOLD|UMLDSDB|UMDB|TWS|WSO2_PUB|WSO2|UMODB|UDMDB'

daily=`date +%j`
server=`uname -n`
banner='##########################################################################'
exit_rc="0"

# names of the files listed below
out_name=$this_pgm_$server.d$daily      # Name of report
out_temp=$this_pgm_$server.temp     # Name of work file

# path names and file names
rpt_out=$out_dir/$out_name      # Report
rpt_tmp=$out_dir/$out_temp      # File holding temporary results

out_error_run=wr_collect_db2reptr_$server.err
###########################################################
############### Fim Declaravao de variaveis ###############
###########################################################

# Verificar se o script esta em execucao
# Create the Locking dir if it doesn't exist
if [[ ! -d "$vlockdir" ]]; then
    mkdir -p $vlockdir
fi

#Check if there is currently a lock in place, if so then exit, if not then create a lock
if [ -f "$vlockdir/$this_pgm.lock" ]; then
    echo "myscript is currently already running"
    exit
else
    touch $vlockdir/$this_pgm.lock
fi

#===================================================================
# Functions
#===================================================================
Run_Cmd ( )
{
  if [[ -f $rpt_tmp ]]; then
    rm -f $rpt_tmp
  fi
  cmd="db2 -ec +o -v -z$rpt_tmp $db2_cmd"
  sqlcode=$($cmd)
  cat $rpt_tmp    | tee -a $rpt_out
}

Handle_Error ( )
{
  datetime=$(date +"Date: %D  Time: %T")                 # Timestamp for errors
  # Write out error msg to file and send out the single error
  echo "$banner"                       | tee -a $rpt_tmp
  echo " "                             | tee -a $rpt_tmp
  echo "Program: $this_pgm"   | tee -a $rpt_tmp
  echo "$datetime  $server" | tee -a $rpt_tmp
  echo "$error_msg"                    | tee -a $rpt_tmp
  echo " "                             | tee -a $rpt_tmp
  echo "$banner"                       | tee -a $rpt_tmp
  cat $rpt_tmp >> $rpt_out      # Write out this error to the report
  if [[ -f $rpt_tmp ]] ; then      # Temporary work file
    rm -f $rpt_tmp
  fi
}

Exit_Error ( )
{
  Clean_Up
  if [[ "$exit_rc" != 0 ]] ; then
    echo "Program $this_pgm terminating because of errors." | tee -a $rpt_out
    #mail -s "$server - $this_pgm failed" $mail_id < $rpt_out
  fi
  #exit $exit_rc
}

Clean_Up ( )
{
  ###echo "db2 connect reset" | tee -a $rpt_out
  ###db2 connect reset
  if [[ -f $rpt_out ]]; then
    chmod 664 $rpt_out
  fi
  if [[ -f $rpt_tmp ]]; then
    rm -f $rpt_tmp
  fi
}

Update_Controle_Execucao_Erro ( )
{
  db2 connect to $vdb
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to connect to database $vdb - act quickly - rc = $sqlcode"
    exit_rc="20"
    Handle_Error
    #Exit_Error
  fi

  # Update a row into stg.controle_execucao table to register the error message 
  SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT_TABLE_SIZE"; db2 connect reset > /dev/null`
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to retrieve SNAPSHOT_ID from DBA.DB_HIST_SNAPSHOT_TABLE_SIZE table"
    exit_rc="8"                    # Set a bad return code
    Handle_Error                   # Will add to error file
    #Exit_Error
  fi
  db2_cmd="update DBA.DB_HIST_SNAPSHOT_TABLE_SIZE set (status, END_TIME, sqlcode, DESCRIPTION) = (-1, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
  Run_Cmd
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to update error message data into DBA.DB_HIST_SNAPSHOT_TABLE_SIZE table"
    exit_rc="8"                    # Set a bad return code
    Handle_Error                   # Will add to error file
    #Exit_Error
  fi
}


###########################################################
### Certificar que a tabela DBA.DB_HIST_VOLUMETRIA_TABELA nao esta com status LOAD PENDING
db2 connect to $vdb > /dev/null
db2 "declare CUR_VOLUMETRIA_TABELA cursor for SELECT * FROM DBA.DB_HIST_VOLUMETRIA_TABELA T1 WITH UR"
db2 "load from CUR_VOLUMETRIA_TABELA of cursor terminate into DBA.DB_HIST_VOLUMETRIA_TABELA nonrecoverable"
db2 connect reset
########################################### Inicio ###########################################

# Abre conexao com a base repositorio - DB2REPTR
db2 connect to $vdb user $vuser using $vpws > /dev/null

for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -viE $vdbexceptlist)
###for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -i seg_tbp)
do
      # Variavel para armazenar a data de coleta que alimentara o campo SNAPSHOT_TIMESTAMP das tabelas do WR
      vdata=`date +"%Y-%m-%d %H:%M:00"`

      # VOLUMETRIA_TABELA
      vtable='VOLUMETRIA_TABELA'
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="INSERT INTO DBA.DB_HIST_SNAPSHOT_TABLE_SIZE (DBNAME, TABNAME, BEGIN_TIME, STATUS) VALUES ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT_TABLE_SIZE table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        #Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user db2inst1 using $vpws for 
WITH QTD_IND AS
        (SELECT COUNT(1) AS NR_INDICE, T1.TABSCHEMA, T1.TABNAME
           FROM SYSCAT.INDEXES T1
          WHERE 1 = 1 AND T1.TABSCHEMA NOT LIKE 'SYS%' AND T1.TABSCHEMA NOT LIKE 'IBM_%' AND T1.TABSCHEMA NOT LIKE 'ASN%'
          GROUP BY T1.TABNAME, T1.TABSCHEMA),
C AS
    (SELECT T2.OWNER,T2.TABSCHEMA,T2.TABNAME,T2.CARD,
     SUM(T3.AVGCOLLEN + (CASE NULLS WHEN 'Y' THEN 1 ELSE 0 END) + (CASE WHEN T3.TYPENAME IN ('LONG VARCHAR','VARCHAR') THEN T3.LENGTH ELSE 0 END)+(CASE WHEN T3.TYPENAME in ('CLOB','BLOB','XML') THEN '2147483647' ELSE 0 END)) AS NR_MAX_LINHA_BYTES
    FROM SYSCAT.TABLES T2 INNER JOIN SYSCAT.COLUMNS T3 ON (T2.TABSCHEMA = T3.TABSCHEMA AND T2.TABNAME = T3.TABNAME)
   WHERE 1 = 1 AND T2.TABSCHEMA NOT LIKE 'SYS%' AND T2.TABSCHEMA NOT LIKE 'IBM_%' AND T2.TABSCHEMA NOT LIKE 'ASN%'
GROUP BY T2.OWNER,T2.TABSCHEMA,T2.TABNAME,T2.CARD WITH UR)
SELECT
    (SELECT '$vdata' FROM SYSIBM.SYSDUMMY1) AS DTH_COLETA,
    (SELECT RTRIM(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) AS DS_SERVIDOR,
    UPPER(CURRENT SERVER) AS DS_DATABASE,
    T3.OWNER AS DS_OWNER,
    T3.TABSCHEMA AS DS_SCHEMA,
    T3.TABNAME AS DS_TABELA,
    T5.NR_INDICE,
    T3.CARD AS NR_LINHA,
    SUM(T4.DATA_OBJECT_P_SIZE + T4.INDEX_OBJECT_P_SIZE + T4.LONG_OBJECT_P_SIZE + T4.LOB_OBJECT_P_SIZE + T4.XML_OBJECT_P_SIZE) AS NR_TAMANHO_KB,
    T3.NR_MAX_LINHA_BYTES
FROM C T3 INNER JOIN TABLE(SYSPROC.ADMIN_GET_TAB_INFO(T3.TABSCHEMA, T3.TABNAME)) T4 ON (T3.TABSCHEMA = T4.TABSCHEMA AND T3.TABNAME = T4.TABNAME)
          LEFT JOIN QTD_IND T5 ON T3.TABSCHEMA = T5.TABSCHEMA AND T3.TABNAME = T5.TABNAME
GROUP BY T3.OWNER,T3.TABSCHEMA,T3.TABNAME,T5.NR_INDICE,T3.CARD,NR_MAX_LINHA_BYTES ORDER BY NR_MAX_LINHA_BYTES DESC WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        #Exit_Error
      fi

      db2_cmd="load from cur_$vtable of cursor MODIFIED BY identitymissing insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        #Exit_Error
      fi
      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT_TABLE_SIZE where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="UPDATE DBA.DB_HIST_SNAPSHOT_TABLE_SIZE  SET (STATUS, END_TIME, SQLCODE, DESCRIPTION) = (0, CURRENT TIMESTAMP, $sqlcode, '$error_msg') WHERE SNAPSHOT_ID = $SNAPSHOT_ID AND TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT_TABLE_SIZE table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        #Exit_Error
      fi

      db2 "declare CUR_VOLUMETRIA_TABELA cursor database $vdb user db2inst1 using $vpws for SELECT * FROM DBA.DB_HIST_VOLUMETRIA_TABELA T1 WITH UR"
      db2 "load from CUR_VOLUMETRIA_TABELA of cursor terminate into DBA.DB_HIST_VOLUMETRIA_TABELA nonrecoverable"
done

###########################################################
### Certificar que nenhuma tabela do WR esta com status LOAD PENDING
db2 connect to $vdb > /dev/null
db2 "declare CUR_VOLUMETRIA_TABELA cursor for SELECT * FROM DBA.DB_HIST_VOLUMETRIA_TABELA T1 WITH UR"
db2 "load from CUR_VOLUMETRIA_TABELA of cursor terminate into DBA.DB_HIST_VOLUMETRIA_TABELA nonrecoverable"
db2 connect reset
########################################### Fim ##############################################
#release the lock
rm "$vlockdir/$this_pgm.lock"