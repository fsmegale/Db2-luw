#!/bin/bash
#**************************************************************************************************
#
#       Autor: Walter Flavio
#       Data: 27/04/2017
#       Versao 1.0 --> Criacao
#       Descricao:
#               Script que coleta dados de conexoes que estao "batendo" na porta de conexao nos servidores de banco de dados
#		O objetivo e reter estes dados de conexoes para avaliacao futura no dimensionamento das conexoes configuradas
#		no DB2.
#
#
#	Log de Revisao:
#		Use esta area para registrar alteracoes no script assim mantendo um historico de contribuicoes
#
#	Dependencias:
#               -> N/A
#
#**************************************************************************************************

# Carregar as variaveis do DB2
. $HOME/sqllib/db2profile
export PATH=$PATH:/usr/local/bin
#===================================================================
# Variables
#===================================================================
vdata=`date +'%Y%m%d_%H'`
vdb=db2reptr
vuser=xxxxxxx
vpws=xxxxxxx
this_pgm=wr_collect_sumaryhostconn
vdir=$HOME/scripts/dbworkload
vdirtmp=/db2/db2inst1/db2reptr/data1/dbwr_logs/wr_collect_hostconnections.tmp/
vtmpfile=$vdirtmp$this_pgm.tmp.$vdata
voutfile=$vdirtmp$this_pgm.$vdata

###################################################################################################
### Certificar que a tabela DBA.DB_HIST_SUMMARY_CONN_HOST nao esta com status LOAD PENDING
### e carrega o arquivo ServidoresDb2Production.txt dinamicamente a partir da tabela DBA.SERVIDORES
db2 connect to db2reptr
db2 -x "SELECT DISTINCT TRIM(DS_SERVIDOR) FROM DBA.SERVIDORES WHERE DS_AMBIENTE = 'PRD' AND DS_SERVIDOR LIKE 'DB2%' WITH UR" > $vdir/ServidoresDb2Production.txt
db2 "DECLARE CUR_DB_HIST_SUMMARY_CONN_HOST CURSOR FOR SELECT * FROM SYSIBM.SYSDUMMY1 WITH UR"
db2 "LOAD FROM CUR_DB_HIST_SUMMARY_CONN_HOST OF CURSOR TERMINATE INTO DBA.DB_HIST_SUMMARY_CONN_HOST NONRECOVERABLE"
db2 connect reset
###################################################################################################
###################################################################################################

### Exclui o arquivo known_hosts afim de impedir erros na conexao ssh_pass quando o servidor alterado
rm /home/db2inst1/.ssh/known_hosts
###################################################################################################
###################################################################################################

############################################# Inicio ##############################################
$vdir/LoopServers.sh /media/share_db2/Scripts/LoopServers/Configs/ServidoresDb2Production_ALL.txt $vdir/sh_wr_verificaconexoeshost.sh > $vtmpfile

cat $vtmpfile | grep -iE "db2p|db2h|db2t|db2d" | grep -v "\-\-" | grep -vE "Nome do Servidor|Host" > $voutfile
rm $vtmpfile

db2 connect to $vdb user $vuser using $vpws > /dev/null
db2 "load from $voutfile of del modified by coldel| insert into DBA.DB_HIST_SUMMARY_CONN_HOST nonrecoverable"
############################################# Fim #################################################
###################################################################################################
