#!/bin/bash
#**************************************************************************************************
#
#       Autor: Walter Flavio
#       Data: 25/02/2017
#
#       Descricao:
#               Script que coleta dados das views/table functions das bases e armazena na base DB2REPTR,
#               assim mantendo o historico de dados para analise das bases.
#               A frequencia de execucao sera a cada 3 horas
#	Grupo de coleta diaria das tabelas do catalogo
#        - SYSIBMADM.PRIVILEGES
#        - SYSCAT.ROLEAUTH
#        - SYSIBMADM.REG_VARIABLES
#        - SYSCAT.TABAUTH
#        - SYSCAT_DBAUTH
#        - SYSCAT.TABLESPACES
#        - SYSCAT_TABLES
#	 - SYSCAT_DATAPARTITONS
#        - SYSCAT_INDEXES
#        - SYSCAT_COLUMNS
#
#**************************************************************************************************

# Carregar as variaveis do DB2
. $HOME/sqllib/db2profile

export PATH=$PATH:$HOME/sqllib/bin

###########################################################
############# Inicio Declaravao de variaveis ##############
###########################################################
# Dados para conexao na base $vdb, base repositorio WR - Workload Repository
vdb=db2reptr
vuser=xxxxxxx
vpws=xxxxxxx
vlockdir=/tmp/lockdir

this_pgm=`basename "$0" | cut -d'.' -f1`
wr_report_dir=/db2/db2inst1/db2reptr/data1/dbwr_logs
out_dir=$wr_report_dir/$this_pgm.rpt         # Report directory
rpt_retained=99
warning=false
status=0

vdbexceptlist='ARCHIVE|ARCHCOMP|COOP_TCF|STADV|TRAVELER|STPS|STMS|STSC|WIKIS|OPNACT|SNCOMM|METRICS|FEBDB|COGNOS|BLOGS|FILES|CONCORD|MOBILE|PEOPLEDB|DOGEAR|HOMEPAGE|FORUM|COGNOS|BDICC|BDCEGCD|BDCFGICC|BDFSM|BDFNMAIL|BDCE|BDIER|BDCN|BDPE|COOP_TCF|ARCHCOMP|STG_20|DSMDB|REPDBOLD|UMLDSDB|UMDB|TWS|WSO2_PUB|WSO2'

daily=`date +%j`
server=`uname -n`
banner='##########################################################################'
exit_rc="0"

# names of the files listed below
out_name=wr_collect_db2reptr_$server.d$daily      # Name of report
out_temp=wr_collect_db2reptr_$server.temp     # Name of work file

# path names and file names
rpt_out=$out_dir/$out_name      # Report
rpt_tmp=$out_dir/$out_temp      # File holding temporary results

out_error_run=wr_collect_db2reptr_$server.err
###########################################################
############### Fim Declaravao de variaveis ###############
###########################################################

# Verificar se o script esta em execucao
# Create the Locking dir if it doesn't exist
if [[ ! -d "$vlockdir" ]]; then
    mkdir -p $vlockdir
fi

#Check if there is currently a lock in place, if so then exit, if not then create a lock
if [ -f "$vlockdir/$this_pgm.lock" ]; then
    echo "myscript is currently already running"
    exit
else
    touch $vlockdir/$this_pgm.lock
fi

#===================================================================
# Functions
#===================================================================
Run_Cmd ( )
{
  if [[ -f $rpt_tmp ]]; then
    rm -f $rpt_tmp
  fi
  cmd="db2 -ec +o -v -z$rpt_tmp $db2_cmd"
  sqlcode=$($cmd)
  cat $rpt_tmp    | tee -a $rpt_out
}

Handle_Error ( )
{
  datetime=$(date +"Date: %D  Time: %T")                 # Timestamp for errors
  # Write out error msg to file and send out the single error
  echo "$banner"                       | tee -a $rpt_tmp
  echo " "                             | tee -a $rpt_tmp
  echo "Program: $this_pgm"   | tee -a $rpt_tmp
  echo "$datetime  $server" | tee -a $rpt_tmp
  echo "$error_msg"                    | tee -a $rpt_tmp
  echo " "                             | tee -a $rpt_tmp
  echo "$banner"                       | tee -a $rpt_tmp
  cat $rpt_tmp >> $rpt_out      # Write out this error to the report
  if [[ -f $rpt_tmp ]] ; then      # Temporary work file
    rm -f $rpt_tmp
  fi
}

Exit_Error ( )
{
  Clean_Up
  if [[ "$exit_rc" != 0 ]] ; then
    echo "Program $this_pgm terminating because of errors." | tee -a $rpt_out
    #mail -s "$server - $this_pgm failed" $mail_id < $rpt_out
  fi
  ### exit $exit_rc
}

Clean_Up ( )
{
  ###echo "db2 connect reset" | tee -a $rpt_out
  ###db2 connect reset
  if [[ -f $rpt_out ]]; then
    chmod 664 $rpt_out
  fi
  if [[ -f $rpt_tmp ]]; then
    rm -f $rpt_tmp
  fi
}

Update_Controle_Execucao_Erro ( )
{
  db2 connect to $vdb
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to connect to database $vdb - act quickly - rc = $sqlcode"
    exit_rc="20"
    Handle_Error
    Exit_Error
  fi

  # Update a row into stg.controle_execucao table to register the error message 
  SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to retrieve SNAPSHOT_ID from DBA.DB_HIST_SNAPSHOT table"
    exit_rc="8"                    # Set a bad return code
    Handle_Error                   # Will add to error file
    Exit_Error
  fi
  db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (-1, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
  Run_Cmd
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to update error message data into DBA.DB_HIST_SNAPSHOT table"
    exit_rc="8"                    # Set a bad return code
    Handle_Error                   # Will add to error file
    Exit_Error
  fi
}

### Certificar que nenhuma tabela do WR esta com status LOAD PENDING
db2 connect to $vdb user $vuser using $vpws > /dev/null
# Declare cursor
db2 "DECLARE CUR_SYSIBMADM_PRIVILEGES CURSOR FOR SELECT * FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_ROLEAUTH CURSOR FOR SELECT * FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_REG_VARIABLES CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSIBMADM_DBCFG CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_GET_SYSTEM_RESOURCES CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_TABAUTH CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_DBAUTH CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_TABLESPACES CURSOR FOR SELECT * FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_TABLES CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_INDEXES CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_COLUMNS CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_MON_GET_CACHE_STMT CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_MON_GET_CONTAINER CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_MON_GET_MEMORY_POOL CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_MON_GET_MEMORY_SET CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_TBSP_UTILIZATION CURSOR FOR SELECT * FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_MON_GET_TABLESPACE CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_WORKLOADS CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_WLM_GET_WORKLOAD_STATS CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_MON_TBSP_UTILIZATION CURSOR FOR SELECT 1 FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_DATAPARTITIONS CURSOR FOR SELECT * FROM SYSIBM.SYSDUMMY1 T1 WITH UR"
db2 "DECLARE CUR_TABLESPACE_USAGE CURSOR FOR SELECT * FROM SYSIBM.SYSDUMMY1 T1 WITH UR"

# Load cursor ... terminate into
db2 "LOAD FROM CUR_SYSIBMADM_PRIVILEGES OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSIBMADM_PRIVILEGES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_ROLEAUTH OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_ROLEAUTH NONRECOVERABLE"
db2 "LOAD FROM CUR_REG_VARIABLES OF CURSOR TERMINATE INTO DBA.DB_HIST_REG_VARIABLES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSIBMADM_DBCFG OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSIBMADM_DBCFG NONRECOVERABLE"
db2 "LOAD FROM CUR_GET_SYSTEM_RESOURCES OF CURSOR TERMINATE INTO DBA.DB_HIST_ENV_GET_SYSTEM_RESOURCES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_TABAUTH OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_TABAUTH NONRECOVERABLE"
db2 "LOAD FROM CUR_DBAUTH OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_DBAUTH NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_TABLESPACES OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_TABLESPACES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_TABLES OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_TABLES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_INDEXES OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_INDEXES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_COLUMNS OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_COLUMNS NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_CACHE_STMT OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_PKG_CACHE_STMT NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_CONTAINER OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_CONTAINER NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_MEMORY_POOL OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_MEMORY_POOL NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_MEMORY_SET OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_MEMORY_SET NONRECOVERABLE"
db2 "LOAD FROM CUR_TBSP_UTILIZATION OF CURSOR TERMINATE INTO DBA.DB_HIST_TBSP_UTILIZATION NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_TABLESPACE OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_TABLESPACE NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_WORKLOADS OF CURSOR TERMINATE INTO DBA.DB_HIST_WORKLOADS NONRECOVERABLE"
db2 "LOAD FROM CUR_WLM_GET_WORKLOAD_STATS OF CURSOR TERMINATE INTO DBA.DB_HIST_WLM_GET_WORKLOAD_STATS NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_TBSP_UTILIZATION OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_TBSP_UTILIZATION NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_DATAPARTITIONS OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_DATAPARTITIONS NONRECOVERABLE"
db2 "LOAD FROM CUR_TABLESPACE_USAGE OF CURSOR TERMINATE INTO DBA.DB_HIST_TABLESPACE_USAGE NONRECOVERABLE"
db2 connect reset

########################################### Inicio ###########################################
# Bloco com as tabelas do grupo que serao coletados os dados apenas 1 vez por dia
# Abre conexao com a base repositorio - DB2REPTR
db2 connect to $vdb user $vuser using $vpws > /dev/null

for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -viE $vdbexceptlist)
###for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -i cnv_tbp)
do
      # Variavel para armazenar a data de coleta que alimentara o campo SNAPSHOT_TIMESTAMP das tabelas do WR
      vdata1=`date +"%Y-%m-%d %H:%M:00"`

      # SYSIBMADM.PRIVILEGES
      vtable='SYSIBMADM_PRIVILEGES'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT RTRIM(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.* FROM SYSIBMADM.PRIVILEGES T1 WITH UR"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT.ROLEAUTH
      vtable='SYSCAT_ROLEAUTH'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT RTRIM(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.* FROM SYSCAT.ROLEAUTH T1 WITH UR"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSIBMADM.REG_VARIABLES
      vtable='REG_VARIABLES'
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_reg_variables cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.* FROM SYSIBMADM.REG_VARIABLES T1 WITH UR"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT.TABAUTH
      vtable='SYSCAT_TABAUTH'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.* FROM SYSCAT.TABAUTH T1 WITH UR"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT_DBAUTH
      vtable='SYSCAT_DBAUTH'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.* FROM SYSCAT.DBAUTH T1 WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi      

      # SYSCAT.TABLESPACES
      vtable='SYSCAT_TABLESPACES'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT RTRIM(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,TBSPACE,OWNER,OWNERTYPE,CREATE_TIME,TBSPACEID,TBSPACETYPE,DATATYPE,EXTENTSIZE,PREFETCHSIZE,OVERHEAD,TRANSFERRATE,WRITEOVERHEAD,WRITETRANSFERRATE,PAGESIZE,DBPGNAME,BUFFERPOOLID,DROP_RECOVERY,NGNAME,DEFINER,DATATAG,SGNAME,SGID,EFFECTIVEPREFETCHSIZE FROM SYSCAT.TABLESPACES WITH UR"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT_TABLES
      vtable='SYSCAT_TABLES'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,TABSCHEMA,TABNAME,OWNER,OWNERTYPE,TYPE,STATUS,BASE_TABSCHEMA,BASE_TABNAME,ROWTYPESCHEMA,ROWTYPENAME,CREATE_TIME,ALTER_TIME,INVALIDATE_TIME,STATS_TIME,COLCOUNT,TABLEID,TBSPACEID,CARD,NPAGES,FPAGES,OVERFLOW,TBSPACE,INDEX_TBSPACE,LONG_TBSPACE,PARENTS,CHILDREN,SELFREFS,KEYCOLUMNS,KEYINDEXID,KEYUNIQUE,CHECKCOUNT,DATACAPTURE,CONST_CHECKED,PMAP_ID,PARTITION_MODE,LOG_ATTRIBUTE,PCTFREE,APPEND_MODE,REFRESH,REFRESH_TIME,LOCKSIZE,VOLATILE,ROW_FORMAT,PROPERTY,STATISTICS_PROFILE,COMPRESSION,ROWCOMPMODE,ACCESS_MODE,CLUSTERED,ACTIVE_BLOCKS,DROPRULE,MAXFREESPACESEARCH,AVGCOMPRESSEDROWSIZE,AVGROWCOMPRESSIONRATIO,AVGROWSIZE,PCTROWSCOMPRESSED,LOGINDEXBUILD,CODEPAGE,COLLATIONSCHEMA,COLLATIONNAME,COLLATIONSCHEMA_ORDERBY,COLLATIONNAME_ORDERBY,ENCODING_SCHEME,PCTPAGESSAVED,LAST_REGEN_TIME,SECPOLICYID,PROTECTIONGRANULARITY,AUDITPOLICYID,AUDITPOLICYNAME,AUDITEXCEPTIONENABLED,DEFINER,ONCOMMIT,LOGGED,ONROLLBACK,LASTUSED,CONTROL,TEMPORALTYPE,REMARKS FROM SYSCAT.TABLES WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT_INDEXES
      vtable='SYSCAT_INDEXES'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,INDSCHEMA,INDNAME,OWNER,OWNERTYPE,TABSCHEMA,TABNAME,COLNAMES,UNIQUERULE,MADE_UNIQUE,COLCOUNT,UNIQUE_COLCOUNT,INDEXTYPE,ENTRYTYPE,PCTFREE,IID,NLEAF,NLEVELS,FIRSTKEYCARD,FIRST2KEYCARD,FIRST3KEYCARD,FIRST4KEYCARD,FULLKEYCARD,CLUSTERRATIO,CLUSTERFACTOR,SEQUENTIAL_PAGES,DENSITY,USER_DEFINED,SYSTEM_REQUIRED,CREATE_TIME,STATS_TIME,PAGE_FETCH_PAIRS,MINPCTUSED,REVERSE_SCANS,INTERNAL_FORMAT,COMPRESSION,IESCHEMA,IENAME,IEARGUMENTS,INDEX_OBJECTID,NUMRIDS,NUMRIDS_DELETED,NUM_EMPTY_LEAFS,AVERAGE_RANDOM_FETCH_PAGES,AVERAGE_RANDOM_PAGES,AVERAGE_SEQUENCE_GAP,AVERAGE_SEQUENCE_FETCH_GAP,AVERAGE_SEQUENCE_PAGES,AVERAGE_SEQUENCE_FETCH_PAGES,TBSPACEID,LEVEL2PCTFREE,PAGESPLIT,AVGPARTITION_CLUSTERRATIO,AVGPARTITION_CLUSTERFACTOR,AVGPARTITION_PAGE_FETCH_PAIRS,PCTPAGESSAVED,DATAPARTITION_CLUSTERFACTOR,INDCARD,AVGLEAFKEYSIZE,AVGNLEAFKEYSIZE,OS_PTR_SIZE,COLLECTSTATISTCS,DEFINER,LASTUSED,PERIODNAME,PERIODPOLICY,MADE_WITHOUTOVERLAPS,NULLKEYS,FUNC_PATH,REMARKS FROM SYSCAT.INDEXES WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT_COLUMNS
      vtable='SYSCAT_COLUMNS'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     

      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, TABSCHEMA,TABNAME,COLNAME,COLNO,TYPESCHEMA,TYPENAME,LENGTH,SCALE,DEFAULT,NULLS,CODEPAGE,COLLATIONSCHEMA,COLLATIONNAME,LOGGED,COMPACT,COLCARD,HIGH2KEY,LOW2KEY,AVGCOLLEN,HIDDEN,INLINE_LENGTH,IDENTITY,ROWCHANGETIMESTAMP,GENERATED,TEXT,COMPRESS,AVGDISTINCTPERPAGE,PAGEVARIANCERATIO,SUB_COUNT,SUB_DELIM_LENGTH,AVGCOLLENCHAR,IMPLICITVALUE FROM SYSCAT.COLUMNS T1 WHERE T1.TABSCHEMA NOT LIKE 'SYS%' WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # MON_GET_TABLESPACE
      vtable='MON_GET_TABLESPACE'
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,T1.* FROM TABLE(MON_GET_TABLESPACE(NULL,-2)) T1 WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT_DATAPARTITIONS
      vtable='SYSCAT_DATAPARTITIONS'
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP, (SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.DATAPARTITIONNAME,T1.TABSCHEMA,T1.TABNAME,T1.DATAPARTITIONID,T1.TBSPACEID,T1.PARTITIONOBJECTID,T1.LONG_TBSPACEID,T1.ACCESS_MODE,T1.STATUS,T1.SEQNO,T1.LOWINCLUSIVE,T1.LOWVALUE,T1.HIGHINCLUSIVE,T1.HIGHVALUE,T1.CARD,T1.OVERFLOW,T1.NPAGES,T1.FPAGES,T1.ACTIVE_BLOCKS,T1.INDEX_TBSPACEID,T1.AVGROWSIZE,T1.PCTROWSCOMPRESSED,T1.PCTPAGESAVED,T1.AVGCOMPRESSEDROWSIZE,T1.AVGROWCOMPRESSIONRATIO,T1.STATS_TIME,T1.LASTUSED FROM SYSCAT.DATAPARTITIONS T1 WITH UR"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # TABLESPACE_USAGE
      vtable='TABLESPACE_USAGE'
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      db2_cmd="DECLARE CUR_$vtable CURSOR DATABASE $i USER $vuser USING $vpws FOR SELECT (SELECT '$vdata1' FROM SYSIBM.SYSDUMMY1) SNAPSHOT_TIMESTAMP, (SELECT UPPER(TRIM(HOST_NAME)) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,TU.* FROM DBA.TABLESPACE_USAGE AS TU WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT_THRESHOLDS
      vtable='SYSCAT_THRESHOLDS'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT RTRIM(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.* FROM SYSCAT.THRESHOLDS T1 WITH UR"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi




      # SYSCAT_COLIDENTATTRIBUTES      vtable='SYSCAT_COLIDENTATTRIBUTES'
#      vtable='SYSCAT_COLIDENTATTRIBUTES'
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
#      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
#      Run_Cmd
#      if [[ $? != 0 ]]; then
#        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
#        exit_rc="8"                    # Set a bad return code
#        Handle_Error                   # Will add to error file
#        Exit_Error
#      fi
#
#      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) AS SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,T1.*  FROM SYSCAT.COLUMNS T1 WHERE T1.TABSCHEMA NOT LIKE 'SYS%' WITH UR"
#
#      Run_Cmd
#      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
#        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
#        exit_rc="8"                    # Set a bad return code
#        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
#        Handle_Error                   # Will add to error file
#        Exit_Error
#      fi
#      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
#      Run_Cmd
#      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
#        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
#        exit_rc="8"                    # Set a bad return code
#        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
#        Handle_Error                   # Will add to error file
#        Exit_Error
#      fi
#
#      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
#      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
#      Run_Cmd
#      if [[ $? != 0 ]]; then
#        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
#        exit_rc="8"                    # Set a bad return code
#        Handle_Error                   # Will add to error file
#        Exit_Error
#      fi
#
done
########################################### Fim ##############################################
#release the lock
rm "$vlockdir/$this_pgm.lock"
