#!/bin/bash
#**************************************************************************************************
#
#       Autor: Walter Flavio
#       Data: 18/06/2019
#
#       Descricao:
#               Script que coleta dados de leitura e escrita (insert, update, delete) nas tabelas
#
#	Log de Revisao:
#		Use esta area para registrar alteracoes no script assim mantendo um historico de contribuicoes
#
#       Dependencias:
#        -> N/A
#
#**************************************************************************************************
# Carregar as variaveis do DB2
. $HOME/sqllib/db2profile

export PATH=$PATH:$HOME/sqllib/bin
#===================================================================
# Variables
#===================================================================
this_pgm=getdbtableaccess
wr_report_dir=/db2/db2inst1/db2reptr/data1/dbwr_logs
out_dir=$wr_report_dir/$this_pgm.rpt         # Report directory
rpt_retained=99
warning=false
#mail_id='grupogeraddb2@sicoob.com.br'
status=0
vdbexceptlist='COIN_TBP|ARCHIVE|ARCHCOMP|COOP_TCF|STADV|TRAVELER|STPS|STMS|STSC|WIKIS|OPNACT|SNCOMM|METRICS|FEBDB|COGNOS|BLOGS|FILES|CONCORD|MOBILE|PEOPLEDB|DOGEAR|HOMEPAGE|FORUM|COGNOS|BDICC|BDCEGCD|BDCFGICC|BDFSM|BDFNMAIL|BDCE|BDIER|BDCN|BDPE|COOP_TCF|ARCHCOMP|STG_20|DSMDB|REPDBOLD|SCC|RCTDB|WSO|UMODB|UMLDSDB|UMDB|UDMDB|TWS|XMETA'

daily=`date +%j`
server=`uname -n`
banner='##########################################################################'
exit_rc="0"

# names of the files listed below
out_name=wr_collect_db2reptr_$server.d$daily      # Name of report
out_temp=wr_collect_db2reptr_$server.temp     # Name of work file

out_error_run=wr_collect_db2reptr_$server.err

# path names and file names
rpt_out=$out_dir/$out_name      # Report
rpt_tmp=$out_dir/$out_temp      # File holding temporary results

#===================================================================
# Functions
#===================================================================
Run_Cmd ( )
{
  if [[ -f $rpt_tmp ]]; then
    rm -f $rpt_tmp
  fi
  cmd="db2 -ec +o -v -z$rpt_tmp $db2_cmd"
  sqlcode=$($cmd)
  cat $rpt_tmp    | tee -a $rpt_out
}

Handle_Error ( )
{
  datetime=$(date +"Date: %D  Time: %T")                 # Timestamp for errors
  # Write out error msg to file and send out the single error
  echo "$banner"                       | tee -a $rpt_tmp
  echo " "                             | tee -a $rpt_tmp
  echo "Program: $this_pgm"   | tee -a $rpt_tmp
  echo "$datetime  $server" | tee -a $rpt_tmp
  echo "$error_msg"                    | tee -a $rpt_tmp
  echo " "                             | tee -a $rpt_tmp
  echo "$banner"                       | tee -a $rpt_tmp
  cat $rpt_tmp >> $rpt_out      # Write out this error to the report
  if [[ -f $rpt_tmp ]] ; then      # Temporary work file
    rm -f $rpt_tmp
  fi
}

Exit_Error ( )
{
  Clean_Up
  if [[ "$exit_rc" != 0 ]] ; then
    echo "Program $this_pgm terminating because of errors." | tee -a $rpt_out
    #mail -s "$server - $this_pgm failed" $mail_id < $rpt_out
  fi
  ### exit $exit_rc
}

Clean_Up ( )
{
  ###echo "db2 connect reset" | tee -a $rpt_out
  ###db2 connect reset
  if [[ -f $rpt_out ]]; then
    chmod 664 $rpt_out
  fi
  if [[ -f $rpt_tmp ]]; then
    rm -f $rpt_tmp
  fi
}

Update_Controle_Execucao_Erro ( )
{
  db2 connect to $vdb
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to connect to database $vdb - act quickly - rc = $sqlcode"
    exit_rc="20"
    Handle_Error
    Exit_Error
  fi

  # Update a row into stg.controle_execucao table to register the error message 
  SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT"; db2 connect reset > /dev/null`
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to retrieve SNAPSHOT_ID from DBA.DB_HIST_SNAPSHOT table"
    exit_rc="8"                    # Set a bad return code
    Handle_Error                   # Will add to error file
    Exit_Error
  fi
  db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (-1, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
  Run_Cmd
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to update error message data into DBA.DB_HIST_SNAPSHOT table"
    exit_rc="8"                    # Set a bad return code
    Handle_Error                   # Will add to error file
    Exit_Error
  fi
}


export PATH=$PATH:/home/db2inst1/sqllib/bin

###########################################################
############# Inicio Declaravao de variaveis ##############
###########################################################
# Dados para conexao na base $vdb, base repositorio WR - Workload Repository
vdb=db2reptr
#vuser=db2mon
#vpws=JDZwAwaK0N
vuser=xxxxxxx
vpws=xxxxxxx
vlockdir=/tmp/lockdir

#Create the Locking dir if it doesn't exist
if [[ ! -d "$vlockdir" ]]; then
    mkdir -p $vlockdir
fi

#Check if there is currently a lock in place, if so then exit, if not then create a lock
if [ -f "$vlockdir/$this_pgm.lock" ]; then
    echo "myscript is currently already running"
    exit
else
    touch $vlockdir/$this_pgm.lock
fi

###########################################################
############### Fim Declaravao de variaveis ###############
###########################################################

### Certificar que nenhuma tabela do WR esta com status LOAD PENDING
db2 connect to $vdb user $vuser using $vpws > /dev/null

# Declare cursor
db2 "DECLARE CUR_DB_HIST_TABLE_ACCESS CURSOR FOR SELECT * FROM SYSIBM.SYSDUMMY1 T1 WITH UR"

# Load cursor ... terminate into
db2 "LOAD FROM CUR_DB_HIST_TABLE_ACCESS OF CURSOR TERMINATE INTO DBA.DB_HIST_TABLE_ACCESS NONRECOVERABLE"

db2 connect reset

########################################### Inicio ###########################################
# Abre conexao com a base repositorio - DB2REPTR
db2 connect to $vdb user $vuser using $vpws > /dev/null


for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -viE $vdbexceptlist)
###for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -i CNV_TBP)
do
      # Variavel para armazenar a data de coleta que alimentara o campo SNAPSHOT_TIMESTAMP das tabelas do WR
      vdata=`date +"%Y-%m-%d %H:%M:00"`

      # DB_HIST_TABLE_ACCESS
      vtable='TABLE_ACCESS'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for WITH C AS (
SELECT  T1.TABSCHEMA, T1.TABNAME,T2.STATS_TIME, SUM(T2.CARD) AS CARD,
        SUM(T1.TABLE_SCANS) AS TABLE_SCANS, SUM(T1.STATS_ROWS_MODIFIED) AS STATS_ROWS_MODIFIED,
        SUM(T1.ROWS_READ) AS ROWS_READ, SUM(T1.ROWS_INSERTED) AS ROWS_INSERTED, SUM(T1.ROWS_UPDATED) AS ROWS_UPDATED,
SUM(ROWS_DELETED) AS ROWS_DELETED
FROM TABLE(MON_GET_TABLE('','',-1)) T1 INNER JOIN SYSCAT.DATAPARTITIONS T2 ON (T1.TABSCHEMA = T2.TABSCHEMA AND T1.TABNAME = T2.TABNAME AND NVL(T1.DATA_PARTITION_ID,0) = T2.DATAPARTITIONID)
WHERE 1 = 1
  AND T1.TABSCHEMA NOT LIKE 'SYS%' AND T1.TABSCHEMA NOT IN ('REP','IBM_RTMON','ASN','LOG') AND T1.TABNAME NOT IN ('VIW_INSTITUICAO','VIW_LOCALIDADE')
GROUP BY T1.TABSCHEMA, T1.TABNAME,T2.STATS_TIME
),
ID AS (
SELECT C.TBCREATOR, C.TBNAME, C.NAME, S.START, S.INCREMENT, S.MINVALUE, S.MAXVALUE, S.CYCLE, S.CACHE, S.ORDER, S.SEQID, S.LASTASSIGNEDVAL
FROM SYSIBM.SYSCOLUMNS     AS C, SYSIBM.SYSDEPENDENCIES AS D, SYSIBM.SYSSEQUENCES    AS S
WHERE C.TBCREATOR = D.DSCHEMA
    AND C.TBNAME = D.DNAME
    AND D.BNAME = S.SEQNAME
    AND D.BSCHEMA = S.SEQSCHEMA
    AND C.IDENTITY = 'Y'
    AND D.DTYPE = 'T'
    AND D.BTYPE = 'Q'
    AND S.SEQTYPE = 'I'
    AND C.TBCREATOR NOT LIKE 'SYS%'  AND C.TBCREATOR NOT IN ('REP','IBM_RTMON','ASN','LOG') AND C.TBCREATOR NOT IN ('VIW_INSTITUICAO','VIW_LOCALIDADE')
    )
SELECT (select '$vdata' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,TABSCHEMA, TABNAME, STATS_TIME, 
TABLE_SCANS, STATS_ROWS_MODIFIED, ROWS_READ, ROWS_INSERTED, ROWS_UPDATED,
ROWS_DELETED, ID.NAME AS IDENTITY_COLNAME, ID.START AS START_CACHE, ID.INCREMENT AS INCREMENT_CACHE, ID.MINVALUE AS MIN_CACHE_VALUE, ID.MAXVALUE AS MAX_CACHE_VALUE, ID.CYCLE, ID.CACHE, ID.ORDER, ID.LASTASSIGNEDVAL, CARD
FROM C LEFT JOIN ID ON C.TABSCHEMA = ID.TBCREATOR AND C.TABNAME = ID.TBNAME WITH UR"
Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi          
done
########################################### Fim ##############################################
#release the lock
rm "$vlockdir/$this_pgm.lock"
