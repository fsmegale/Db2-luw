#!/bin/bash
#**************************************************************************************************
#
#       Autor: Walter Flavio
#       Data: 25/02/2017
#
#       Descricao:
#               Script que coleta dados das views/table functions das bases e armazena na base DB2REPTR,
#               assim mantendo o historico de dados para analise das bases.
#               A frequencia de execucao sera a cada 3 horas
#	Grupo de coleta diaria das tabelas do catalogo
#        - SYSIBMADM.PRIVILEGES
#        - SYSCAT.ROLEAUTH
#        - SYSIBMADM.REG_VARIABLES
#        - SYSCAT.TABAUTH
#        - SYSCAT_DBAUTH
#        - SYSCAT.TABLESPACES
#        - SYSCAT_TABLES
#        - SYSCAT_INDEXES
#        - SYSCAT_COLUMNS
#
#	Grupo de coleta a cada 2 horas
#        - MON_GET_BUFFERPOOL
#        - MON_GET_PKG_CACHE_STMT
#        - MON_GET_CONTAINER
#        - MON_GET_MEMORY_POOL
#        - MON_GET_MEMORY_SET
#        - TBSP_UTILIZATION
#        - MON_GET_TABLESPACE
#        - SYSCAT_WORKLOADS
#        - SYSCAT_SERVICECLASSES
#        - WLM_GET_WORKLOAD_STATS
#        - MON_GET_TRANSACTION_LOG
#        - MON_TBSP_UTILIZATION
#
#	Log de Revisao:
#		Use esta area para registrar alteracoes no script assim mantendo um historico de contribuicoes
#
#	Data:24/04/2017
#	 - Reformulado o script de coleta de modo a manter, registrado em banco de dados, controle das execuções
#	   e seus respectivos código de erros. A contribuição foi dada pelo DBA Felipe Alkain.
#
#       Data: 03/09/2018
#        - Adicionado verificacao se o script estiver em execucao. Se estiver, saira evitando concorrencia nas tabelas de metadados e destino
#       Dependencias:
#        -> N/A
#
#**************************************************************************************************

# Carregar as variaveis do DB2
. $HOME/sqllib/db2profile

export PATH=$PATH:$HOME/sqllib/bin

###########################################################
############# Inicio Declaravao de variaveis ##############
###########################################################
# Dados para conexao na base $vdb, base repositorio WR - Workload Repository
vdb=db2reptr
vuser=xxxxxxx
vpws=xxxxxxx
vlockdir=/tmp/lockdir

this_pgm=getdbworkload
wr_report_dir=/db2/db2inst1/db2reptr/data1/dbwr_logs
out_dir=$wr_report_dir/$this_pgm.rpt         # Report directory
rpt_retained=99
warning=false
status=0

vdbexceptlist='COOP_TCF|COOP_TCE|ARCHIVE|STADV|TRAVELER|STPS|STMS|STSC|WIKIS|OPNACT|SNCOMM|METRICS|FEBDB|BLOGS|FILES|CONCORD|MOBILE|PEOPLEDB|DOGEAR|HOMEPAGE|FORUM|BDICC|BDCEGCD|BDCFGICC|BDFSM|BDFNMAIL|BDCE|BDIER|BDCN|BDPE|ARCHCOMP|STG_20|DSMDB|REPDBOLD'

daily=`date +%j`
server=`uname -n`
banner='##########################################################################'
exit_rc="0"

# names of the files listed below
out_name=wr_collect_db2reptr_$server.d$daily      # Name of report
out_temp=wr_collect_db2reptr_$server.temp     # Name of work file

# path names and file names
rpt_out=$out_dir/$out_name      # Report
rpt_tmp=$out_dir/$out_temp      # File holding temporary results

out_error_run=wr_collect_db2reptr_$server.err
###########################################################
############### Fim Declaravao de variaveis ###############
###########################################################

# Verificar se o script esta em execucao
# Create the Locking dir if it doesn't exist
if [[ ! -d "$vlockdir" ]]; then
    mkdir -p $vlockdir
fi

#Check if there is currently a lock in place, if so then exit, if not then create a lock
if [ -f "$vlockdir/$this_pgm.lock" ]; then
    echo "myscript is currently already running"
    exit
else
    touch $vlockdir/$this_pgm.lock
fi

#===================================================================
# Functions
#===================================================================
Run_Cmd ( )
{
  if [[ -f $rpt_tmp ]]; then
    rm -f $rpt_tmp
  fi
  cmd="db2 -ec +o -v -z$rpt_tmp $db2_cmd"
  sqlcode=$($cmd)
  cat $rpt_tmp    | tee -a $rpt_out
}

Handle_Error ( )
{
  datetime=$(date +"Date: %D  Time: %T")                 # Timestamp for errors
  # Write out error msg to file and send out the single error
  echo "$banner"                       | tee -a $rpt_tmp
  echo " "                             | tee -a $rpt_tmp
  echo "Program: $this_pgm"   | tee -a $rpt_tmp
  echo "$datetime  $server" | tee -a $rpt_tmp
  echo "$error_msg"                    | tee -a $rpt_tmp
  echo " "                             | tee -a $rpt_tmp
  echo "$banner"                       | tee -a $rpt_tmp
  cat $rpt_tmp >> $rpt_out      # Write out this error to the report
  if [[ -f $rpt_tmp ]] ; then      # Temporary work file
    rm -f $rpt_tmp
  fi
}

Exit_Error ( )
{
  Clean_Up
  if [[ "$exit_rc" != 0 ]] ; then
    echo "Program $this_pgm terminating because of errors." | tee -a $rpt_out
    #mail -s "$server - $this_pgm failed" $mail_id < $rpt_out
  fi
  ### exit $exit_rc
}

Clean_Up ( )
{
  ###echo "db2 connect reset" | tee -a $rpt_out
  ###db2 connect reset
  if [[ -f $rpt_out ]]; then
    chmod 664 $rpt_out
  fi
  if [[ -f $rpt_tmp ]]; then
    rm -f $rpt_tmp
  fi
}

Update_Controle_Execucao_Erro ( )
{
  db2 connect to $vdb
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to connect to database $vdb - act quickly - rc = $sqlcode"
    exit_rc="20"
    Handle_Error
    Exit_Error
  fi

  # Update a row into stg.controle_execucao table to register the error message 
  SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to retrieve SNAPSHOT_ID from DBA.DB_HIST_SNAPSHOT table"
    exit_rc="8"                    # Set a bad return code
    Handle_Error                   # Will add to error file
    Exit_Error
  fi
  db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (-1, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
  Run_Cmd
  if [[ $? != 0 ]]; then
    error_msg="Error: Unable to update error message data into DBA.DB_HIST_SNAPSHOT table"
    exit_rc="8"                    # Set a bad return code
    Handle_Error                   # Will add to error file
    Exit_Error
  fi
}

### Certificar que nenhuma tabela do WR esta com status LOAD PENDING
db2 connect to $vdb user $vuser using $vpws > /dev/null

# Declare cursor
db2 "DECLARE CUR_SYSIBMADM_PRIVILEGES CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT * FROM SYSIBMADM.PRIVILEGES T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_ROLEAUTH CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT * FROM SYSCAT.ROLEAUTH T1 WITH UR"
db2 "DECLARE CUR_REG_VARIABLES CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSIBMADM.REG_VARIABLES T1 WITH UR"
db2 "DECLARE CUR_SYSIBMADM_DBCFG CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSIBMADM.DBCFG T1 WITH UR"
db2 "DECLARE CUR_GET_SYSTEM_RESOURCES CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM TABLE(SYSPROC.ENV_GET_SYSTEM_RESOURCES()) T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_TABAUTH CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSCAT.TABAUTH T1 WITH UR"
db2 "DECLARE CUR_DBAUTH CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSCAT.DBAUTH T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_TABLESPACES CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT * FROM SYSCAT.TABLESPACES T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_TABLES CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSCAT.TABLES T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_INDEXES CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSCAT.INDEXES T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_COLUMNS CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSCAT.COLUMNS T1 WITH UR"
db2 "DECLARE CUR_MON_GET_CACHE_STMT CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM TABLE(MON_GET_PKG_CACHE_STMT('D',NULL,NULL,-2)) T1 WITH UR"
db2 "DECLARE CUR_MON_GET_CONTAINER CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM TABLE(MON_GET_CONTAINER('',-2)) T1 WITH UR"
db2 "DECLARE CUR_MON_GET_MEMORY_POOL CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM TABLE(MON_GET_MEMORY_POOL(NULL, CURRENT_SERVER, -2)) T1 WITH UR"
db2 "DECLARE CUR_MON_GET_MEMORY_SET CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM TABLE(MON_GET_MEMORY_SET(NULL, CURRENT_SERVER, -2)) T1 WITH UR"
db2 "DECLARE CUR_TBSP_UTILIZATION CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT * FROM SYSIBMADM.TBSP_UTILIZATION T1 WITH UR"
db2 "DECLARE CUR_SYSCAT_WORKLOADS CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSCAT.WORKLOADS T1 WITH UR"
db2 "DECLARE CUR_WLM_GET_WORKLOAD_STATS CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM TABLE(wlm_get_workload_stats(CAST(NULL AS VARCHAR(128)), -2)) T1 WITH UR"
db2 "DECLARE CUR_MON_TBSP_UTILIZATION CURSOR DATABASE $vdb USER $vuser USING $vpws FOR SELECT 1 FROM SYSIBMADM.mon_tbsp_utilization T1 WITH UR"

# Load cursor ... terminate into
db2 "LOAD FROM CUR_SYSIBMADM_PRIVILEGES OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSIBMADM_PRIVILEGES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_ROLEAUTH OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_ROLEAUTH NONRECOVERABLE"
db2 "LOAD FROM CUR_REG_VARIABLES OF CURSOR TERMINATE INTO DBA.DB_HIST_REG_VARIABLES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSIBMADM_DBCFG OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSIBMADM_DBCFG NONRECOVERABLE"
db2 "LOAD FROM CUR_GET_SYSTEM_RESOURCES OF CURSOR TERMINATE INTO DBA.DB_HIST_ENV_GET_SYSTEM_RESOURCES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_TABAUTH OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_TABAUTH NONRECOVERABLE"
db2 "LOAD FROM CUR_DBAUTH OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_DBAUTH NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_TABLESPACES OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_TABLESPACES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_TABLES OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_TABLES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_INDEXES OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_INDEXES NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_COLUMNS OF CURSOR TERMINATE INTO DBA.DB_HIST_SYSCAT_COLUMNS NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_CACHE_STMT OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_PKG_CACHE_STMT NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_CONTAINER OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_CONTAINER NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_MEMORY_POOL OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_MEMORY_POOL NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_GET_MEMORY_SET OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_GET_MEMORY_SET NONRECOVERABLE"
db2 "LOAD FROM CUR_TBSP_UTILIZATION OF CURSOR TERMINATE INTO DBA.DB_HIST_TBSP_UTILIZATION NONRECOVERABLE"
db2 "LOAD FROM CUR_SYSCAT_WORKLOADS OF CURSOR TERMINATE INTO DBA.DB_HIST_WORKLOADS NONRECOVERABLE"
db2 "LOAD FROM CUR_WLM_GET_WORKLOAD_STATS OF CURSOR TERMINATE INTO DBA.DB_HIST_WLM_GET_WORKLOAD_STATS NONRECOVERABLE"
db2 "LOAD FROM CUR_MON_TBSP_UTILIZATION OF CURSOR TERMINATE INTO DBA.DB_HIST_MON_TBSP_UTILIZATION NONRECOVERABLE"
db2 connect reset

########################################### Inicio ###########################################

# Abre conexao com a base repositorio - DB2REPTR
db2 connect to $vdb user $vuser using $vpws > /dev/null

for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -viE $vdbexceptlist)
###for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -iE "car_tbp")
do
      # Variavel para armazenar a data de coleta que alimentara o campo SNAPSHOT_TIMESTAMP das tabelas do WR
      vdata1=`date +"%Y-%m-%d %H:%M:00"`

      # MON_GET_PKG_CACHE_STMT
      vtable='MON_GET_PKG_CACHE_STMT'      
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2 "insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"

      db2 "declare cur_$vtable cursor database $i user $vuser using $vpws for
WITH PCT_CPU AS (
        SELECT
    CASE
        WHEN TOTAL_DB_CPU_TIME = 0
        THEN 1
        ELSE TOTAL_DB_CPU_TIME
    END                              TOTAL_DB_CPU_TIME
FROM ( SELECT SUM(TOTAL_CPU_TIME) AS TOTAL_DB_CPU_TIME
        FROM TABLE (MON_GET_PKG_CACHE_STMT(NULL, NULL, NULL, NULL)) )
          )
SELECT *
FROM (SELECT  
        (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,
        T1.INSERT_TIMESTAMP,
        T1.MAX_COORD_STMT_EXEC_TIMESTAMP,        
        T1.STMT_EXEC_TIME,
        T1.NUM_EXECUTIONS,
        T1.ROWS_MODIFIED,
        T1.ROWS_READ,
        T1.ROWS_RETURNED,
        T1.ROWS_READ     / CASE WHEN T1.NUM_EXECUTIONS = 0 THEN 1 ELSE T1.NUM_EXECUTIONS END ROWS_READ_RATIO,
        T1.ROWS_RETURNED / CASE WHEN T1.NUM_EXECUTIONS = 0 THEN 1 ELSE T1.NUM_EXECUTIONS END ROWS_RETURNED_RATIO,
        E.TOTAL_DB_CPU_TIME AS TOTAL_CPU_DB,
        T1.TOTAL_CPU_TIME AS TOTAL_CPU_QUERY,
        ((T1.TOTAL_CPU_TIME * 100) / E.TOTAL_DB_CPU_TIME) AS PCT_CPU,
        T1.QUERY_COST_ESTIMATE,
        T1.DEADLOCKS,        
        T1.LOG_BUFFER_WAIT_TIME,
        T1.LOG_DISK_WAIT_TIME / CASE WHEN T1.LOG_DISK_WAIT_TIME = 0 THEN 1 ELSE LOG_DISK_WAIT_TIME END LOG_DISK_WAIT_TIME,
        SUBSTR(UPPER( VARCHAR(T1.STMT_TEXT, 30000)), 1, 10000) AS TEXTO,
	T1.POOL_DATA_L_READS + T1.POOL_INDEX_L_READS + T1.POOL_TEMP_DATA_L_READS + T1.POOL_TEMP_INDEX_L_READS AS TOTALIO
FROM TABLE (MON_GET_PKG_CACHE_STMT ('D', NULL, NULL, -2)) T1 CROSS JOIN (SELECT TOTAL_DB_CPU_TIME FROM PCT_CPU) AS E) 
ORDER BY TOTALIO DESC, PCT_CPU DESC, ROWS_READ DESC, ROWS_RETURNED DESC 
FETCH FIRST 100 ROWS ONLY
"
      db2 "load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2 "update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"

      # MON_GET_CONTAINER
      vtable='MON_GET_CONTAINER'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP, (select '$vdata1' from sysibm.SYSDUMMY1) DT_COLETA, (SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,T1.* FROM TABLE(MON_GET_CONTAINER('',-2)) T1 WITH UR"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi  

      # MON_GET_MEMORY_POOL
      vtable='MON_GET_MEMORY_POOL'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,T1.* FROM TABLE(MON_GET_MEMORY_POOL(NULL, CURRENT_SERVER, -2)) T1 WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi      

      # MON_GET_MEMORY_SET
      vtable='MON_GET_MEMORY_SET'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,T1.* FROM TABLE(MON_GET_MEMORY_SET(NULL, CURRENT_SERVER, -2)) T1 WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # TBSP_UTILIZATION
      vtable='TBSP_UTILIZATION'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,TBSP_ID,TBSP_NAME,TBSP_TYPE,TBSP_CONTENT_TYPE,TBSP_CREATE_TIME,TBSP_STATE,TBSP_TOTAL_SIZE_KB,TBSP_USABLE_SIZE_KB,TBSP_USED_SIZE_KB,TBSP_FREE_SIZE_KB,TBSP_UTILIZATION_PERCENT,TBSP_TOTAL_PAGES,TBSP_USABLE_PAGES,TBSP_USED_PAGES,TBSP_FREE_PAGES,TBSP_PAGE_TOP,TBSP_PAGE_SIZE,TBSP_EXTENT_SIZE,TBSP_PREFETCH_SIZE,TBSP_MAX_SIZE,TBSP_INCREASE_SIZE,TBSP_INCREASE_SIZE_PERCENT,TBSP_LAST_RESIZE_TIME,TBSP_LAST_RESIZE_FAILED,TBSP_USING_AUTO_STORAGE,TBSP_AUTO_RESIZE_ENABLED,DBPGNAME,TBSP_NUM_CONTAINERS,REMARKS,DBPARTITIONNUM FROM SYSIBMADM.TBSP_UTILIZATION WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # SYSCAT_WORKLOADS
      # vtable='SYSCAT_WORKLOADS'
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      #db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      #Run_Cmd
      #if [[ $? != 0 ]]; then
      #  error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
      #  exit_rc="8"                    # Set a bad return code
      #  Handle_Error                   # Will add to error file
      #  Exit_Error
      #fi     
      #db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME,T1.* FROM SYSCAT.WORKLOADS T1 WITH UR"

      #Run_Cmd
      #if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
      #  error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
      #  exit_rc="8"                    # Set a bad return code
      #  Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
      #  Handle_Error                   # Will add to error file
      #  Exit_Error
      #fi
      #db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      #Run_Cmd
      #if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
      #  error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
      #  exit_rc="8"                    # Set a bad return code
      #  Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
      #  Handle_Error                   # Will add to error file
      #  Exit_Error
      #fi

      #SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      #db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      #Run_Cmd
      #if [[ $? != 0 ]]; then
      #  error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
      #  exit_rc="8"                    # Set a bad return code
      #  Handle_Error                   # Will add to error file
      #  Exit_Error
      #fi

      # WLM_GET_WORKLOAD_STATS
      vtable='WLM_GET_WORKLOAD_STATS'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     
      db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (SELECT '$vdata1' FROM SYSIBM.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT RTRIM(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.* FROM TABLE(WLM_GET_WORKLOAD_STATS(CAST(NULL AS VARCHAR(128)), -2)) T1 WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      # MON_TBSP_UTILIZATION
      vtable='MON_TBSP_UTILIZATION'       
      # Insert a row into DBA.DB_HIST_SNAPSHOT table to register the start of the snapshot and any given error execution
      db2_cmd="insert into DBA.DB_HIST_SNAPSHOT (DBNAME, TABNAME, BEGIN_TIME, STATUS) values ('$i', '$vtable', current timestamp, 1)"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi     

	db2_cmd="declare cur_$vtable cursor database $i user $vuser using $vpws for SELECT (select '$vdata1' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP, (select '$vdata1' from sysibm.SYSDUMMY1) DT_COLETA,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, T1.TBSP_NAME,T1.MEMBER,T1.TBSP_TYPE,T1.TBSP_CONTENT_TYPE,T1.TBSP_STATE,T1.TBSP_PAGE_SIZE,T1.TBSP_EXTENT_SIZE,T1.TBSP_PREFETCH_SIZE,T1.TBSP_USING_AUTO_STORAGE,T1.TBSP_AUTO_RESIZE_ENABLED,T1.TBSP_TOTAL_SIZE_KB,T1.TBSP_USABLE_SIZE_KB,T1.TBSP_UTILIZATION_PERCENT FROM SYSIBMADM.mon_tbsp_utilization T1 WITH UR"

      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
      db2_cmd="load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable"
      Run_Cmd
      if [[ $sqlcode != 0 && $sqlcode != 3107 ]]; then
        error_msg="Error: Unable to create cursor cur_$vtable - sqlcode = $sqlcode"
        exit_rc="8"                    # Set a bad return code
        Update_Controle_Execucao_Erro  # Update a record into stg.controle_execucao table
        Handle_Error                   # Will add to error file
        Exit_Error
      fi

      SNAPSHOT_ID=`db2 connect to $vdb > /dev/null; db2 -x "select max(SNAPSHOT_ID) from DBA.DB_HIST_SNAPSHOT where TABNAME = '$vtable'"; db2 connect reset > /dev/null`
      db2_cmd="update DBA.DB_HIST_SNAPSHOT set (status, END_TIME, sqlcode, DESCRIPTION) = (0, current timestamp, $sqlcode, '$error_msg') where SNAPSHOT_ID = $SNAPSHOT_ID and TABNAME = '$vtable'"
      Run_Cmd
      if [[ $? != 0 ]]; then
        error_msg="Error: Unable to insert data into DBA.DB_HIST_SNAPSHOT table"
        exit_rc="8"                    # Set a bad return code
        Handle_Error                   # Will add to error file
        Exit_Error
      fi
done
########################################### Fim ##############################################
#release the lock
rm "$vlockdir/$this_pgm.lock"
