#!/bin/bash
#**************************************************************************************************
#
#       Autor: Walter Flavio
#       Data: 25/04/2016
#       Versao 1.0 --> Criacao
#       Descricao:
#               Script que coleta dados das views/table functions das bases e armazena na base DB2REPTR
#		no schema DBA, assim mantendo o historico de dados para analise das bases.
#
#       Dependencias:
#               -> N/A
#
#**************************************************************************************************
# Carregar as variaveis do DB2
. $HOME/sqllib/db2profile

export PATH=$PATH:$HOME/sqllib/bin

#===================================================================
# Variables
#===================================================================
this_pgm=`basename "$0" | cut -d'.' -f1`
wr_report_dir=/db2/db2inst1/db2reptr/data1/dbwr_logs
out_dir=$wr_report_dir/$this_pgm.rpt         # Report directory
rpt_retained=99
warning=false
#mail_id='grupogeraddb2@sicoob.com.br'
status=0
vdbexceptlist='CRE_TBP|SPB_TBP|CLI_TBP|ITG_TBP|CAR_TBC|CCA_TBC|CCO_TBC|CLI_TBC|CNL_TBC|CNV_TBC|COEX_TBC|COIN_TBC|COOP_TBA|CRE_TBC|CTB_TBC|GED_TBC|INF_TBC|INV_TBC|PAD_TBP|RIS_TBC|SEG_TBC|STG_DWS|STG_TBC|WSO|XMETA|TWS|IADB|DB2REPTR|ARCHIVE|ANALYAUD|ANALYTIC|RCTDB|AUD_OLD|STADV|TRAVELER|STPS|STMS|STSC|WIKIS|OPNACT|SNCOMM|METRICS|FEBDB|COGNOS|BLOGS|FILES|CONCORD|MOBILE|PEOPLEDB|DOGEAR|HOMEPAGE|FORUM|COGNOS|BDICC|BDCEGCD|BDCFGICC|BDFSM|BDFNMAIL|BDCE|BDIER|BDCN|BDPE|ARCHCOMP|COOP_TCE|STG_20|DSMDB|REPDBOLD'

daily=`date +%j`
server=`uname -n`
banner='##########################################################################'
exit_rc="0"

# names of the files listed below
out_name=wr_collect_db2reptr_$server.d$daily      # Name of report
out_temp=wr_collect_db2reptr_$server.temp     # Name of work file

# path names and file names
rpt_out=$out_dir/$out_name      # Report
rpt_tmp=$out_dir/$out_temp      # File holding temporary results

export PATH=$PATH:/home/db2inst1/sqllib/bin

###########################################################
############# Inicio Declaravao de variaveis ##############
###########################################################
# Dados para conexao na base $vdb, base repositorio WR - Workload Repository
vdb=db2reptr
vuser=xxxxxxx
vpws=xxxxxxx
vlockdir=/tmp/lockdir

#Create the Locking dir if it doesn't exist
if [[ ! -d "$vlockdir" ]]; then
    mkdir -p $vlockdir
fi

#Check if there is currently a lock in place, if so then exit, if not then create a lock
if [ -f "$vlockdir/$this_pgm.lock" ]; then
    echo "myscript is currently already running"
    echo $this_pgm.lock
    exit
else
    touch $vlockdir/$this_pgm.lock
fi

###########################################################
############### Fim Declaravao de variaveis ###############
###########################################################


### Certificar que nenhuma tabela do WR esta com status LOAD PENDING
db2 connect to db2reptr user $vuser using $vpws > /dev/null
db2 "declare cur_DB_HIST_DB_CONNECTIONS cursor for SELECT * FROM SYSIBM.SYSDUMMY1 WITH UR"
db2 "load from cur_DB_HIST_DB_CONNECTIONS of cursor terminate into DBA.DB_HIST_DB_CONNECTIONS nonrecoverable"


db2 connect reset

db2 connect to db2reptr user $vuser using $vpws > /dev/null

  for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -ivE $vdbexceptlist)
  ###for i in $(db2 list db directory | grep -i alias | awk '{print $4}' | sort | grep -i 'cdi_tbp')
  # Variavel para armazenar a data de coleta que alimentara o campo SNAPSHOT_TIMESTAMP das tabelas do WR
  do
      # DB_HIST_DB_CONNECTIONS
      vdata=`date +"%Y-%m-%d %H:%M:00"`
      vtable='DB_CONNECTIONS'
      db2 "declare cur_$vtable cursor database $i user db2inst1 using $vpws for
	  WITH LOG_INFO AS
    (SELECT
            TOTAL_LOG_USED * 100 / (TOTAL_LOG_USED + TOTAL_LOG_AVAILABLE)       AS TOTAL_LOG_USED ,
            (TOTAL_LOG_USED + TOTAL_LOG_AVAILABLE)                              AS TOTAL_LOG ,
            A.APPLID_HOLDING_OLDEST_XACT
        FROM TABLE(SYSPROC.MON_GET_TRANSACTION_LOG(-2)) AS A
     ),
CONN_LIST AS (     
SELECT        
        T1.CONNECTION_START_TIME,
        T1.UOW_START_TIME,
        T1.UOW_STOP_TIME,
        T1.PREV_UOW_STOP_TIME,
        T1.UOW_COMP_STATUS,
        T1.TOTAL_CPU_TIME,
        T1.CLIENT_IDLE_WAIT_TIME,
        T1.APPLICATION_HANDLE HANDLE,
        T1.SESSION_AUTH_ID USERNAME,
        T1.APPLICATION_NAME PROGRAM,
        T1.WORKLOAD_OCCURRENCE_STATE,
        T1.LAST_REQUEST_TYPE,
        T2.LOG_BUFFER_WAIT_TIME,
        T2.UOW_LOG_SPACE_USED,
        ((T2.UOW_LOG_SPACE_USED * 100) * 2 / D.TOTAL_LOG) AS LOG_USED_PER_TRANSACTION,
        D.TOTAL_LOG_USED,
        T1.NUM_LOCKS_HELD,
        T1.LOCK_WAITS,
        T1.LOCK_WAIT_TIME,
        T1.LOCK_ESCALS,
        T1.DEADLOCKS,
        T1.LOCK_TIMEOUTS,
        T1.ROWS_READ,
        T1.ROWS_RETURNED,
        T1.ROWS_MODIFIED,
        T1.TOTAL_SORTS,
        T1.SORT_OVERFLOWS,
        T1.TOTAL_APP_ROLLBACKS,
        T1.CLIENT_IPADDR,
CASE
             WHEN T1.CLIENT_PRDID = 'SQL09010' THEN 'DB2 Client v9.1.0.189'
             WHEN T1.CLIENT_PRDID like 'SQL100%' THEN 'DB2 Client Version 10.1' 
             WHEN SUBSTR(T1.CLIENT_PRDID,5,1) = 3 AND SUBSTR(T1.CLIENT_PRDID,6,2) IN (01) THEN 'DB2 Client Version 9.1 (JDBC 3.0 driver)' 
             WHEN SUBSTR(T1.CLIENT_PRDID,5,1) = 3 AND SUBSTR(T1.CLIENT_PRDID,6,2) IN (57,61) THEN 'DB2 Client Version v9.7' 
             WHEN SUBSTR(T1.CLIENT_PRDID,5,1) = 3 AND SUBSTR(T1.CLIENT_PRDID,6,2) IN (63,64,65) THEN 'DB2 Version 10.1 (JDBC 3.0 driver)' 
             WHEN SUBSTR(T1.CLIENT_PRDID,5,1) = 4 AND SUBSTR(T1.CLIENT_PRDID,6,2) IN (13,14,15) THEN 'DB2 Version 10.1 (JDBC 4.0 driver)'
             WHEN SUBSTR(T1.CLIENT_PRDID,5,1) = 3 AND SUBSTR(T1.CLIENT_PRDID,6,2) IN (66,67,68,69) THEN 'DB2 Version 10.5 (JDBC 3.0 driver)' 
             WHEN SUBSTR(T1.CLIENT_PRDID,5,1) = 4 AND SUBSTR(T1.CLIENT_PRDID,6,2) IN (16,17,18,19) THEN 'DB2 Version 10.5 (JDBC 4.0 driver)' 
             WHEN SUBSTR(T1.CLIENT_PRDID,1,7) = 'SQL1005' THEN 'DB2 Client Version 10.5' 
             WHEN SUBSTR(T1.CLIENT_PRDID,5,1) = 3 AND SUBSTR(T1.CLIENT_PRDID,6,2) IN (71,72) THEN 'DB2 Version 11.1 (JDBC 3.0 driver)' 
             WHEN SUBSTR(T1.CLIENT_PRDID,5,1) = 4 AND SUBSTR(T1.CLIENT_PRDID,6,2) IN (21,22,23,24,25) THEN 'DB2 Version 11.1 (JDBC 4.0 driver)' 
             WHEN SUBSTR(T1.CLIENT_PRDID,1,6) = 'SQL110' THEN 'DB2 Client Version 11.1' 
        END JDBC_CLIENT_VERSION,
       T3.STMT_TEXT,
       T4.MEMORY_POOL_USED AS MEMORY_HANDLE_USED_BYTES, 
       T4.MEMORY_POOL_USED_HWM AS MEMORY_HANDLE_USED_HWM_BYTES,
       T1.UOW_CLIENT_IDLE_WAIT_TIME,
       APPLID_HOLDING_OLDEST_XACT,
       T1.CLIENT_PRDID,
       T2.SERVICE_SUPERCLASS_NAME, T2.SERVICE_SUBCLASS_NAME, T2.WORKLOAD_NAME
 FROM TABLE(MON_GET_CONNECTION(CAST(NULL AS BIGINT), -2)) AS T1
INNER JOIN TABLE(MON_GET_UNIT_OF_WORK(NULL,-2)) AS T2 ON T1.APPLICATION_HANDLE = T2.APPLICATION_HANDLE
LEFT OUTER JOIN SYSIBMADM.LONG_RUNNING_SQL T3 ON (T1.APPLICATION_HANDLE = T3.AGENT_ID)
        CROSS JOIN
            (SELECT
                    TOTAL_LOG_USED,
                    TOTAL_LOG,
                    APPLID_HOLDING_OLDEST_XACT
                FROM
                    LOG_INFO) AS D
INNER JOIN TABLE(MON_GET_MEMORY_POOL(NULL, CURRENT_SERVER, -2)) T4 ON T1.APPLICATION_HANDLE = T4.APPLICATION_HANDLE
)
SELECT (select '$vdata' from sysibm.SYSDUMMY1) SNAPSHOT_TIMESTAMP,(SELECT rtrim(HOST_NAME) FROM TABLE(SYSPROC.ENV_GET_SYS_INFO()) T) SERVIDOR,CURRENT SERVER DBNAME, CONN_LIST.* FROM CONN_LIST"
      db2 "load from cur_$vtable of cursor insert into dba.db_hist_$vtable nonrecoverable" >> $rpt_out
      done

## Certificar que nenhuma tabela do WR esta com status LOAD PENDING
db2 connect to db2reptr user $vuser using $vpws > /dev/null
db2 "declare cur_DB_HIST_DB_CONNECTIONS cursor database db2reptr user db2inst1 using $vpws for SELECT * FROM SYSIBM.SYSDUMMY1 WITH UR"
db2 "load from cur_DB_HIST_DB_CONNECTIONS of cursor terminate into DBA.DB_HIST_DB_CONNECTIONS nonrecoverable"

########################################### Fim ##############################################
#release the lock
rm "$vlockdir/$this_pgm.lock"
